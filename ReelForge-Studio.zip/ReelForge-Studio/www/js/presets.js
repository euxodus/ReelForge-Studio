/* ReelForge Studio — presets: subtitle styles, video looks, EQ curves */
(function () {
  'use strict';

  // Four colorways applied to every template -> 30 x 4 = 120 subtitle styles
  const PALETTES = [
    { key: 'sun',  name: 'Sun',  a: '#FFD60A', b: '#1A1400' },
    { key: 'lime', name: 'Lime', a: '#7CFF6B', b: '#0A1A06' },
    { key: 'rose', name: 'Rose', a: '#FF4F8B', b: '#22000C' },
    { key: 'sky',  name: 'Sky',  a: '#3FD2FF', b: '#001822' }
  ];

  const K = '#000000', W = '#FFFFFF';
  const sh = (c, b, x, y) => ({ c, b, x: x || 0, y: y || 0 });

  // Each template gets the palette (a = accent, b = deep tone) and returns a style.
  // size is a fraction of the canvas short side; strokeW is a fraction of the font size.
  const TEMPLATES = [
    { name: 'Karaoke Pop', f: p => ({ font: 'Montserrat', weight: 900, size: .072, fill: W, stroke: K, strokeW: .16, hl: p.a, upper: true, anim: 'pop', shadow: sh('rgba(0,0,0,.55)', 8, 0, 4) }) },
    { name: 'Creator Bold', f: p => ({ font: 'Montserrat', weight: 900, size: .078, fill: W, stroke: K, strokeW: .2, hl: p.a, hlScale: 1.12, upper: true, anim: 'bounce', shadow: sh('rgba(0,0,0,.7)', 0, 0, 6) }) },
    { name: 'Word Box', f: p => ({ font: 'Poppins', weight: 800, size: .066, fill: W, stroke: K, strokeW: .1, hlBg: p.a, hlFill: p.b, anim: 'pop' }) },
    { name: 'Clean Cinema', f: p => ({ font: 'Rubik', weight: 700, size: .056, fill: W, shadow: sh('rgba(0,0,0,.85)', 10, 0, 2), hl: p.a, anim: 'fade' }) },
    { name: 'Caption Bar', f: p => ({ font: 'Manrope', weight: 800, size: .054, fill: W, bg: { c: 'rgba(8,8,12,.72)', pad: .32, r: .22 }, hl: p.a, anim: 'fade' }) },
    { name: 'Solid Block', f: p => ({ font: 'Montserrat', weight: 900, size: .062, fill: p.b, bg: { c: p.a, pad: .3, r: .18 }, upper: true, anim: 'pop' }) },
    { name: 'Neon Sign', f: p => ({ font: 'Righteous', weight: 400, size: .07, fill: W, glow: p.a, stroke: p.a, strokeW: .06, anim: 'fade' }) },
    { name: 'Headline', f: p => ({ font: 'Bebas Neue', weight: 400, size: .095, fill: W, stroke: K, strokeW: .12, hl: p.a, upper: true, ls: .04, anim: 'slide' }) },
    { name: 'Poster Stack', f: p => ({ font: 'Anton', weight: 400, size: .085, fill: p.a, stroke: K, strokeW: .14, upper: true, anim: 'pop', shadow: sh('rgba(0,0,0,.6)', 0, 0, 5) }) },
    { name: 'Comic Burst', f: p => ({ font: 'Bangers', weight: 400, size: .088, fill: p.a, stroke: K, strokeW: .2, shadow: sh(K, 0, 5, 5), ls: .03, anim: 'pop', hl: W }) },
    { name: 'Marker', f: p => ({ font: 'Permanent Marker', weight: 400, size: .068, fill: W, shadow: sh(p.a, 0, 4, 4), anim: 'fade', hl: p.a }) },
    { name: 'Sunset Script', f: p => ({ font: 'Pacifico', weight: 400, size: .066, fill: W, glow: p.a, anim: 'fade' }) },
    { name: 'Retro Diner', f: p => ({ font: 'Lobster', weight: 400, size: .074, fill: p.a, stroke: p.b, strokeW: .14, shadow: sh(K, 0, 4, 4), anim: 'pop' }) },
    { name: 'Typewriter', f: p => ({ font: 'Space Grotesk', weight: 700, size: .052, fill: W, bg: { c: 'rgba(0,0,0,.8)', pad: .26, r: .06 }, anim: 'type', cursor: p.a }) },
    { name: 'Editorial', f: p => ({ font: 'Playfair Display', weight: 900, size: .068, fill: W, shadow: sh('rgba(0,0,0,.8)', 12, 0, 3), hl: p.a, anim: 'fade' }) },
    { name: 'Notebook', f: p => ({ font: 'Caveat', weight: 700, size: .085, fill: p.a, shadow: sh('rgba(0,0,0,.75)', 6, 0, 2), anim: 'type' }) },
    { name: 'Arcade', f: p => ({ font: 'Bungee', weight: 400, size: .06, fill: W, stroke: p.a, strokeW: .1, shadow: sh(K, 0, 5, 5), upper: true, anim: 'pop', hl: p.a }) },
    { name: 'Scoreboard', f: p => ({ font: 'Teko', weight: 600, size: .09, fill: p.b, bg: { c: p.a, pad: .22, r: .04 }, upper: true, ls: .03, anim: 'slide' }) },
    { name: 'Chrome Fade', f: p => ({ font: 'Kanit', weight: 800, size: .074, grad: [W, p.a], stroke: K, strokeW: .1, upper: true, anim: 'pop' }) },
    { name: 'Lower Third', f: p => ({ font: 'Manrope', weight: 700, size: .045, fill: W, shadow: sh('rgba(0,0,0,.9)', 8, 0, 2), hl: p.a, anim: 'slide', y: .86 }) },
    { name: 'Hollow', f: p => ({ font: 'Archivo Black', weight: 400, size: .078, fill: 'rgba(0,0,0,0)', stroke: p.a, strokeW: .08, hlFillWord: p.a, upper: true, anim: 'pop' }) },
    { name: 'Party', f: p => ({ font: 'Luckiest Guy', weight: 400, size: .08, fill: W, stroke: K, strokeW: .2, hl: p.a, hlScale: 1.15, anim: 'bounce', shadow: sh(K, 0, 0, 6) }) },
    { name: 'Offset Shadow', f: p => ({ font: 'Rubik', weight: 900, size: .074, fill: W, shadow: sh(p.a, 0, 6, 6), upper: true, anim: 'slide' }) },
    { name: 'Frosted', f: p => ({ font: 'Poppins', weight: 600, size: .054, fill: W, bg: { c: 'rgba(255,255,255,.2)', pad: .34, r: .5 }, hl: p.a, anim: 'fade' }) },
    { name: 'Serif Card', f: p => ({ font: 'DM Serif Display', weight: 400, size: .064, fill: W, bg: { c: 'rgba(12,10,20,.78)', pad: .3, r: .12 }, hl: p.a, anim: 'fade' }) },
    { name: 'Highlighter', f: p => ({ font: 'Montserrat', weight: 800, size: .062, fill: '#101010', bg: { c: p.a, pad: .16, r: .02 }, anim: 'slide' }) },
    { name: 'Soft Focus', f: p => ({ font: 'Manrope', weight: 800, size: .062, fill: W, shadow: sh('rgba(0,0,0,.6)', 14, 0, 0), hl: p.a, anim: 'fade' }) },
    { name: 'Rise Up', f: p => ({ font: 'Oswald', weight: 700, size: .074, fill: W, stroke: K, strokeW: .12, hl: p.a, upper: true, anim: 'slide' }) },
    { name: 'Gradient Pop', f: p => ({ font: 'Montserrat', weight: 900, size: .076, grad: [p.a, W], stroke: p.b, strokeW: .14, upper: true, anim: 'pop', shadow: sh('rgba(0,0,0,.5)', 6, 0, 4) }) },
    { name: 'One Word', f: p => ({ font: 'Anton', weight: 400, size: .12, fill: p.a, stroke: K, strokeW: .12, upper: true, single: true, anim: 'pop', shadow: sh('rgba(0,0,0,.7)', 0, 0, 6) }) }
  ];

  const SUB_STYLES = [];
  TEMPLATES.forEach((t, ti) => {
    PALETTES.forEach(p => {
      const s = Object.assign({ id: 't' + ti + '_' + p.key, name: t.name + ' ' + p.name, group: t.name, accent: p.a }, t.f(p));
      SUB_STYLES.push(s);
    });
  });

  // Color looks for video and photo clips (CSS canvas filters)
  const LOOKS = [
    { id: 'none', name: 'Original', f: 'none' },
    { id: 'vivid', name: 'Vivid', f: 'saturate(1.45) contrast(1.08)' },
    { id: 'warm', name: 'Golden', f: 'sepia(.22) saturate(1.3) brightness(1.04)' },
    { id: 'cool', name: 'Arctic', f: 'hue-rotate(-12deg) saturate(1.1) brightness(1.03)' },
    { id: 'fade', name: 'Matte', f: 'contrast(.86) brightness(1.08) saturate(.82)' },
    { id: 'bw', name: 'Mono', f: 'grayscale(1) contrast(1.1)' },
    { id: 'noir', name: 'Noir', f: 'grayscale(1) contrast(1.45) brightness(.92)' },
    { id: 'vintage', name: 'Vintage', f: 'sepia(.5) contrast(.92) saturate(.9)' },
    { id: 'teal', name: 'Teal Night', f: 'hue-rotate(-25deg) saturate(1.25) contrast(1.1) brightness(.95)' },
    { id: 'punch', name: 'Punch', f: 'contrast(1.3) saturate(1.25)' },
    { id: 'dream', name: 'Dreamy', f: 'brightness(1.12) saturate(1.15) contrast(.9) blur(.4px)' },
    { id: 'dark', name: 'Moody', f: 'brightness(.82) contrast(1.2) saturate(.85)' }
  ];

  // 10-band graphic EQ
  const EQ_BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  const EQ_PRESETS = [
    { name: 'Flat', g: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    { name: 'Bass boost', g: [7, 6, 5, 2, 0, 0, 0, 0, 0, 0] },
    { name: 'Bass cut', g: [-9, -7, -4, -1, 0, 0, 0, 0, 0, 0] },
    { name: 'Voice', g: [-6, -4, -1, 1, 3, 4, 4, 3, 1, 0] },
    { name: 'Podcast', g: [-4, -2, 1, 2, 1, 2, 3, 2, 1, -1] },
    { name: 'Treble boost', g: [0, 0, 0, 0, 0, 1, 3, 5, 6, 7] },
    { name: 'Rock', g: [5, 4, 2, -1, -2, -1, 2, 4, 5, 5] },
    { name: 'Pop', g: [-1, 1, 3, 4, 3, 0, -1, -1, 1, 2] },
    { name: 'Electronic', g: [6, 5, 1, 0, -2, 1, 0, 2, 4, 5] },
    { name: 'Hip-hop', g: [6, 5, 2, 3, -1, -1, 1, 0, 2, 3] },
    { name: 'Acoustic', g: [3, 3, 2, 1, 2, 2, 3, 3, 2, 1] },
    { name: 'Classical', g: [4, 3, 2, 1, -1, -1, 0, 2, 3, 4] },
    { name: 'Loudness', g: [6, 4, 0, 0, -2, 0, -1, -2, 4, 2] },
    { name: 'Lo-fi', g: [2, 2, 1, 0, 0, -1, -3, -6, -9, -12] }
  ];

  window.Presets = { PALETTES, TEMPLATES, SUB_STYLES, LOOKS, EQ_BANDS, EQ_PRESETS };
})();
