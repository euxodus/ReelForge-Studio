/* ReelForge Studio — audio engine */
(function () {
  'use strict';

  // ---------- building blocks ----------
  const unit = (i, o, osc) => ({ in: i, out: o || i, osc: osc || [] });

  function series(ctx, ...units) {
    const us = units.filter(Boolean).map(u => (u instanceof AudioNode ? unit(u) : u));
    if (!us.length) { const g = ctx.createGain(); return unit(g); }
    for (let i = 0; i < us.length - 1; i++) us[i].out.connect(us[i + 1].in);
    return unit(us[0].in, us[us.length - 1].out, us.flatMap(u => u.osc));
  }

  function parallel(ctx, wetUnit, wet, dry) {
    const i = ctx.createGain(), o = ctx.createGain();
    const d = ctx.createGain(); d.gain.value = dry == null ? 1 : dry;
    const w = ctx.createGain(); w.gain.value = wet;
    i.connect(d); d.connect(o);
    i.connect(wetUnit.in); wetUnit.out.connect(w); w.connect(o);
    return unit(i, o, wetUnit.osc);
  }

  function bq(ctx, type, f, q, g) {
    const n = ctx.createBiquadFilter();
    n.type = type; n.frequency.value = f;
    if (q != null) n.Q.value = q;
    if (g != null) n.gain.value = g;
    return n;
  }
  const hp = (c, f, q) => bq(c, 'highpass', f, q == null ? 0.707 : q);
  const lp = (c, f, q) => bq(c, 'lowpass', f, q == null ? 0.707 : q);
  const peak = (c, f, g, q) => bq(c, 'peaking', f, q == null ? 1 : q, g);
  const lowshelf = (c, f, g) => bq(c, 'lowshelf', f, null, g);
  const highshelf = (c, f, g) => bq(c, 'highshelf', f, null, g);

  function comp(ctx, th, ratio, att, rel, knee) {
    const n = ctx.createDynamicsCompressor();
    n.threshold.value = th; n.ratio.value = ratio;
    n.attack.value = att == null ? 0.01 : att; n.release.value = rel == null ? 0.2 : rel;
    n.knee.value = knee == null ? 6 : knee;
    return n;
  }
  function gain(ctx, v) { const g = ctx.createGain(); g.gain.value = v; return g; }

  function curve(fn, n) {
    n = n || 2048; const c = new Float32Array(n);
    for (let i = 0; i < n; i++) { const x = i * 2 / (n - 1) - 1; c[i] = fn(x); }
    return c;
  }
  function drive(ctx, k) {
    const s = ctx.createWaveShaper();
    s.curve = curve(x => ((1 + k) * x) / (1 + k * Math.abs(x)));
    s.oversample = '2x';
    return s;
  }
  function crush(ctx, bits) {
    const steps = Math.pow(2, bits);
    const s = ctx.createWaveShaper();
    s.curve = curve(x => Math.round(x * steps) / steps, 4096);
    return s;
  }

  function lfo(ctx, freq, amount, target) {
    const o = ctx.createOscillator(); o.frequency.value = freq;
    const g = ctx.createGain(); g.gain.value = amount;
    o.connect(g); g.connect(target);
    return o;
  }

  function echo(ctx, time, fb, wet, tone) {
    const d = ctx.createDelay(3); d.delayTime.value = time;
    const f = gain(ctx, fb);
    const t = lp(ctx, tone || 5000);
    d.connect(t); t.connect(f); f.connect(d);
    return parallel(ctx, unit(d, t), wet, 1);
  }

  const irCache = new WeakMap();
  function impulse(ctx, secs, decay) {
    let m = irCache.get(ctx); if (!m) { m = new Map(); irCache.set(ctx, m); }
    const key = secs + '_' + decay;
    if (m.has(key)) return m.get(key);
    const rate = ctx.sampleRate, len = Math.max(1, Math.floor(rate * secs));
    const buf = ctx.createBuffer(2, len, rate);
    let seed = 1234567;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 * 2 - 1; };
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = rnd() * Math.pow(1 - i / len, decay);
    }
    m.set(key, buf); return buf;
  }
  function reverb(ctx, secs, decay, wet, dry) {
    const c = ctx.createConvolver(); c.buffer = impulse(ctx, secs, decay);
    return parallel(ctx, unit(c), wet, dry == null ? 1 : dry);
  }
  function ring(ctx, freq) {
    const g = ctx.createGain(); g.gain.value = 0;
    const o = lfo(ctx, freq, 1, g.gain);
    return unit(g, g, [o]);
  }
  function tremolo(ctx, freq, depth) {
    const g = ctx.createGain(); g.gain.value = 1 - depth / 2;
    const o = lfo(ctx, freq, depth / 2, g.gain);
    return unit(g, g, [o]);
  }
  function autopan(ctx, freq) {
    const p = ctx.createStereoPanner();
    const o = lfo(ctx, freq, 0.95, p.pan);
    return unit(p, p, [o]);
  }
  function chorus(ctx, wet) {
    const d = ctx.createDelay(0.1); d.delayTime.value = 0.024;
    const o = lfo(ctx, 0.9, 0.005, d.delayTime);
    const d2 = ctx.createDelay(0.1); d2.delayTime.value = 0.031;
    const o2 = lfo(ctx, 0.6, 0.006, d2.delayTime);
    const i = ctx.createGain(), out = ctx.createGain();
    i.connect(d); i.connect(d2); d.connect(out); d2.connect(out);
    return parallel(ctx, unit(i, out, [o, o2]), wet == null ? 0.55 : wet, 0.8);
  }
  function flanger(ctx) {
    const d = ctx.createDelay(0.05); d.delayTime.value = 0.004;
    const o = lfo(ctx, 0.22, 0.0028, d.delayTime);
    const f = gain(ctx, 0.62); d.connect(f); f.connect(d);
    return parallel(ctx, unit(d, d, [o]), 0.7, 0.75);
  }

  // ---------- 36 filter presets ----------
  const FX = [
    { id: 'none', name: 'Original', cat: 'Voice', b: c => series(c, gain(c, 1)) },
    { id: 'podcast', name: 'Podcast', cat: 'Voice', b: c => series(c, hp(c, 80), peak(c, 220, -2.5), peak(c, 3200, 3.5), highshelf(c, 10000, 2), comp(c, -24, 4, 0.006, 0.18), gain(c, 1.45)) },
    { id: 'studio', name: 'Studio voice', cat: 'Voice', b: c => series(c, hp(c, 70), peak(c, 260, -3), peak(c, 5000, 2.5), comp(c, -20, 3), reverb(c, 0.5, 4, 0.08), gain(c, 1.25)) },
    { id: 'broadcast', name: 'Broadcast', cat: 'Voice', b: c => series(c, hp(c, 90), lowshelf(c, 150, 3), peak(c, 3500, 4), comp(c, -28, 8, 0.003, 0.15), gain(c, 1.7), comp(c, -3, 20, 0.001, 0.1, 0)) },
    { id: 'bassmic', name: 'Bass mic', cat: 'Voice', b: c => series(c, hp(c, 40), lowshelf(c, 140, 9), peak(c, 320, 3), highshelf(c, 6000, -4), comp(c, -22, 4), gain(c, 1.15)) },
    { id: 'warm', name: 'Warm vocal', cat: 'Voice', b: c => series(c, lowshelf(c, 200, 4), peak(c, 3000, -2), highshelf(c, 9000, -3), drive(c, 0.8), gain(c, 0.95)) },
    { id: 'bright', name: 'Bright vocal', cat: 'Voice', b: c => series(c, hp(c, 120), peak(c, 4000, 4), highshelf(c, 9000, 6)) },
    { id: 'clarity', name: 'Vocal clarity', cat: 'Voice', b: c => series(c, hp(c, 100), peak(c, 300, -4, 1.2), peak(c, 2500, 5), comp(c, -22, 3), gain(c, 1.2)) },
    { id: 'deesser', name: 'De-esser', cat: 'Voice', b: c => series(c, peak(c, 6500, -8, 3), highshelf(c, 10000, -3), comp(c, -18, 2.5)) },
    { id: 'night', name: 'Night mode', cat: 'Voice', b: c => series(c, comp(c, -36, 10, 0.004, 0.25), highshelf(c, 8000, -4), gain(c, 1.9), comp(c, -2, 20, 0.001, 0.1, 0)) },
    { id: 'loud', name: 'Loudness max', cat: 'Voice', b: c => series(c, comp(c, -30, 6, 0.003, 0.2), gain(c, 2.2), comp(c, -2, 20, 0.001, 0.08, 0)) },
    { id: 'telephone', name: 'Telephone', cat: 'Character', b: c => series(c, hp(c, 400, 0.9), lp(c, 3200, 0.9), peak(c, 1500, 4), drive(c, 3), gain(c, 0.85)) },
    { id: 'walkie', name: 'Walkie-talkie', cat: 'Character', b: c => series(c, hp(c, 600), lp(c, 2600), crush(c, 6), drive(c, 8), gain(c, 0.6), comp(c, -20, 6)) },
    { id: 'megaphone', name: 'Megaphone', cat: 'Character', b: c => series(c, hp(c, 700), lp(c, 4000), peak(c, 2000, 8, 2), drive(c, 15), gain(c, 0.5)) },
    { id: 'am', name: 'AM radio', cat: 'Character', b: c => series(c, hp(c, 250), lp(c, 4500), drive(c, 2), tremolo(c, 0.35, 0.06), gain(c, 0.95)) },
    { id: 'vinyl', name: 'Old vinyl', cat: 'Character', b: c => series(c, hp(c, 120), lp(c, 6000), drive(c, 1.2), tremolo(c, 0.55, 0.05)) },
    { id: 'lofi', name: 'Lo-fi', cat: 'Character', b: c => series(c, hp(c, 150), lp(c, 3500), crush(c, 8), drive(c, 1.5), tremolo(c, 0.3, 0.08)) },
    { id: 'bitcrush', name: 'Bitcrusher', cat: 'Character', b: c => series(c, crush(c, 4), lp(c, 8000), gain(c, 0.8)) },
    { id: 'distortion', name: 'Distortion', cat: 'Character', b: c => series(c, drive(c, 40), lp(c, 7000), gain(c, 0.4)) },
    { id: 'robot', name: 'Robot', cat: 'Character', b: c => series(c, ring(c, 55), echo(c, 0.012, 0.55, 0.6, 9000), gain(c, 1.3)) },
    { id: 'alien', name: 'Alien', cat: 'Character', b: c => series(c, parallel(c, ring(c, 420), 0.7, 0.5), flanger(c), gain(c, 0.7)) },
    { id: 'underwater', name: 'Underwater', cat: 'Space', b: c => series(c, lp(c, 420, 3), chorus(c, 0.6), reverb(c, 1.5, 3, 0.3), gain(c, 0.85)) },
    { id: 'nextroom', name: 'Next room', cat: 'Space', b: c => series(c, hp(c, 80), lp(c, 900), reverb(c, 0.8, 3, 0.35), gain(c, 0.85)) },
    { id: 'smallroom', name: 'Small room', cat: 'Space', b: c => series(c, reverb(c, 0.6, 3, 0.22)) },
    { id: 'hall', name: 'Concert hall', cat: 'Space', b: c => series(c, reverb(c, 2.5, 2.5, 0.35)) },
    { id: 'cathedral', name: 'Cathedral', cat: 'Space', b: c => series(c, hp(c, 80), reverb(c, 5, 1.6, 0.5, 0.85)) },
    { id: 'cave', name: 'Cave', cat: 'Space', b: c => series(c, lp(c, 3000), echo(c, 0.14, 0.35, 0.3), reverb(c, 3, 2, 0.4)) },
    { id: 'stadium', name: 'Stadium', cat: 'Space', b: c => series(c, echo(c, 0.33, 0.3, 0.3, 3500), reverb(c, 2.2, 2.2, 0.3)) },
    { id: 'echo', name: 'Echo', cat: 'Space', b: c => series(c, echo(c, 0.38, 0.45, 0.45)) },
    { id: 'slapback', name: 'Slapback', cat: 'Space', b: c => series(c, echo(c, 0.11, 0.1, 0.45)) },
    { id: '8d', name: '8D audio', cat: 'Space', b: c => series(c, autopan(c, 0.15), reverb(c, 1.2, 3, 0.15)) },
    { id: 'chorus', name: 'Chorus', cat: 'Music', b: c => series(c, chorus(c), gain(c, 0.8)) },
    { id: 'flanger', name: 'Flanger', cat: 'Music', b: c => series(c, flanger(c), gain(c, 0.75)) },
    { id: 'tremolo', name: 'Tremolo', cat: 'Music', b: c => series(c, tremolo(c, 5.5, 0.6)) },
    { id: 'bassboost', name: 'Bass boost', cat: 'Music', b: c => series(c, lowshelf(c, 100, 10), comp(c, -18, 3), gain(c, 0.9)) },
    { id: 'trebleboost', name: 'Treble boost', cat: 'Music', b: c => series(c, highshelf(c, 4000, 9)) }
  ];
  const FX_BY_ID = Object.fromEntries(FX.map(f => [f.id, f]));

  function eqUnit(ctx, gains) {
    if (!gains || gains.every(g => !g)) return null;
    const bands = Presets.EQ_BANDS.map((f, i) => {
      const type = i === 0 ? 'lowshelf' : i === 9 ? 'highshelf' : 'peaking';
      return bq(ctx, type, f, type === 'peaking' ? 1.4 : null, gains[i] || 0);
    });
    return series(ctx, ...bands);
  }

  function clipChain(ctx, clip) {
    const fx = (FX_BY_ID[clip.fx] || FX[0]).b(ctx);
    const vol = ctx.createGain();
    const c = series(ctx, eqUnit(ctx, clip.eq), fx, vol);
    c.vol = vol;
    return c;
  }

  function makeMaster(ctx) {
    const i = ctx.createGain();
    const lim = comp(ctx, -1.5, 12, 0.002, 0.15, 0);
    i.connect(lim);
    return unit(i, lim);
  }

  // Schedule every audio segment that overlaps [from, to) on any (realtime or offline) context.
  // segs: [{clip, buffer, tlStart, srcIn, dur}]
  function schedule(ctx, segs, from, to, ctxStart, dest) {
    const live = [];
    for (const s of segs) {
      if (!s.buffer) continue;
      const segEnd = s.tlStart + s.dur;
      if (segEnd <= from + 0.001 || s.tlStart >= to) continue;
      const off = Math.max(0, from - s.tlStart);
      const when = ctxStart + Math.max(0, s.tlStart - from);
      const playDur = Math.min(segEnd, to) - Math.max(s.tlStart, from);
      if (playDur <= 0.005) continue;
      const src = ctx.createBufferSource(); src.buffer = s.buffer;
      const ch = clipChain(ctx, s.clip);
      src.connect(ch.in); ch.out.connect(dest);
      // volume + fades
      const v = s.clip.volume == null ? 1 : s.clip.volume;
      const fi = Math.min(s.clip.fadeIn || 0, s.dur / 2), fo = Math.min(s.clip.fadeOut || 0, s.dur / 2);
      const gAt = l => v * Math.max(0, Math.min(1, fi > 0 ? l / fi : 1, fo > 0 ? (s.dur - l) / fo : 1));
      const p = ch.vol.gain;
      p.setValueAtTime(gAt(off), when);
      const pts = [fi, s.dur - fo, s.dur].filter(x => x > off + 0.0005).sort((a, b) => a - b);
      for (const x of pts) p.linearRampToValueAtTime(gAt(x), when + (x - off));
      const startAt = Math.max(when, ctx.currentTime);
      src.start(startAt, Math.max(0, s.srcIn + off), playDur);
      ch.osc.forEach(o => { o.start(startAt); try { o.stop(startAt + playDur + 6); } catch (e) {} });
      live.push({ src, ch });
    }
    return live;
  }

  function stopAll(live) {
    for (const l of live) {
      try { l.src.stop(); } catch (e) {}
      try { l.src.disconnect(); l.ch.out.disconnect(); } catch (e) {}
      l.ch.osc.forEach(o => { try { o.stop(); } catch (e) {} });
    }
  }

  async function mixdown(segs, from, to, sampleRate, channels) {
    sampleRate = sampleRate || 44100; channels = channels || 2;
    const len = Math.max(1, Math.ceil((to - from) * sampleRate));
    const ctx = new OfflineAudioContext(channels, len, sampleRate);
    const m = makeMaster(ctx); m.out.connect(ctx.destination);
    schedule(ctx, segs, from, to, 0, m.in);
    return ctx.startRendering();
  }

  // ---------- encoders ----------
  function toWav(buf) {
    const ch = buf.numberOfChannels, sr = buf.sampleRate, n = buf.length;
    const data = new DataView(new ArrayBuffer(44 + n * ch * 2));
    const w = (o, s) => { for (let i = 0; i < s.length; i++) data.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); data.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    data.setUint32(16, 16, true); data.setUint16(20, 1, true); data.setUint16(22, ch, true);
    data.setUint32(24, sr, true); data.setUint32(28, sr * ch * 2, true); data.setUint16(32, ch * 2, true);
    data.setUint16(34, 16, true); w(36, 'data'); data.setUint32(40, n * ch * 2, true);
    const chans = []; for (let c = 0; c < ch; c++) chans.push(buf.getChannelData(c));
    let o = 44;
    for (let i = 0; i < n; i++) for (let c = 0; c < ch; c++) {
      const s = Math.max(-1, Math.min(1, chans[c][i]));
      data.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true); o += 2;
    }
    return new Blob([data], { type: 'audio/wav' });
  }

  function f2i(f) {
    const r = new Int16Array(f.length);
    for (let i = 0; i < f.length; i++) { const s = Math.max(-1, Math.min(1, f[i])); r[i] = s < 0 ? s * 0x8000 : s * 0x7fff; }
    return r;
  }
  async function toMp3(buf, kbps, onProgress) {
    if (!window.lamejs) throw new Error('MP3 encoder failed to load.');
    const ch = Math.min(2, buf.numberOfChannels);
    const enc = new lamejs.Mp3Encoder(ch, buf.sampleRate, kbps || 192);
    const L = f2i(buf.getChannelData(0)), R = ch > 1 ? f2i(buf.getChannelData(1)) : null;
    const out = [], block = 1152, n = L.length;
    for (let i = 0, k = 0; i < n; i += block, k++) {
      const l = L.subarray(i, i + block);
      const d = R ? enc.encodeBuffer(l, R.subarray(i, i + block)) : enc.encodeBuffer(l);
      if (d.length) out.push(new Uint8Array(d));
      if (k % 400 === 0) { onProgress && onProgress(i / n); await new Promise(r => setTimeout(r, 0)); }
    }
    const e = enc.flush(); if (e.length) out.push(new Uint8Array(e));
    onProgress && onProgress(1);
    return new Blob(out, { type: 'audio/mpeg' });
  }

  // Waveform strip (PNG data URL) for timeline clips
  function waveform(buffer, color) {
    const cols = Math.max(60, Math.min(3000, Math.ceil(buffer.duration * 30)));
    const H = 64, cv = document.createElement('canvas'); cv.width = cols; cv.height = H;
    const g = cv.getContext('2d'); g.fillStyle = color || 'rgba(255,255,255,.75)';
    const d = buffer.getChannelData(0), step = Math.max(1, Math.floor(d.length / cols));
    let maxPeak = 0.0001; const peaks = new Float32Array(cols);
    for (let x = 0; x < cols; x++) {
      let m = 0; const s0 = x * step;
      for (let i = 0; i < step; i += 4) { const v = Math.abs(d[s0 + i] || 0); if (v > m) m = v; }
      peaks[x] = m; if (m > maxPeak) maxPeak = m;
    }
    for (let x = 0; x < cols; x++) {
      const h = Math.max(1, (peaks[x] / maxPeak) * (H - 6));
      g.fillRect(x, (H - h) / 2, 0.8, h);
    }
    return cv.toDataURL('image/png');
  }

  window.AudioFX = { FX, FX_BY_ID, schedule, stopAll, makeMaster, mixdown, toWav, toMp3, waveform };
})();
