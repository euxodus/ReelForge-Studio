/* ReelForge Studio — core editor */
'use strict';

// ===================== utilities =====================
const $ = s => document.querySelector(s);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const uid = () => Math.random().toString(36).slice(2, 10);
const ease = k => 1 - Math.pow(1 - k, 3);
const backOut = k => { const c = 1.9; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
function fmt(t) {
  t = Math.max(0, t || 0);
  const m = Math.floor(t / 60), s = Math.floor(t % 60), d = Math.floor((t * 10) % 10);
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0') + '.' + d;
}
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style') el.style.cssText = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k in el && typeof v !== 'string') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(c));
  return el;
}
const nextFrame = () => new Promise(r => requestAnimationFrame(() => r()));

// ===================== icons =====================
const P = {
  plus: 'M12 5v14M5 12h14', undo: 'M9 14L4 9l5-5M4 9h10.5a5.5 5.5 0 010 11H11', redo: 'M15 14l5-5-5-5M20 9H9.5a5.5 5.5 0 000 11H13',
  scissors: 'M6 3.5a2.5 2.5 0 110 5 2.5 2.5 0 010-5zM6 15.5a2.5 2.5 0 110 5 2.5 2.5 0 010-5zM20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12',
  trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6', copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
  volume: 'M11 5L6 9H2v6h4l5 4zM15.5 8.5a5 5 0 010 7M19 5a10 10 0 010 14',
  eq: 'M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6',
  fx: 'M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M17.8 6.2L19 5M3 21l9-9M12.2 6.2L11 5',
  text: 'M4 7V4h16v3M9 20h6M12 4v16', music: 'M9 18V5l12-2v13M6 15a3 3 0 110 6 3 3 0 010-6zM18 13a3 3 0 110 6 3 3 0 010-6z',
  media: 'M3 4h18v16H3zM8 4v16M16 4v16M3 9h5M3 15h5M16 9h5M16 15h5',
  mic: 'M12 2a3 3 0 00-3 3v7a3 3 0 006 0V5a3 3 0 00-3-3zM19 10v2a7 7 0 01-14 0v-2M12 19v3',
  cc: 'M3 5h18v14H3zM10.5 10H9a2 2 0 000 4h1.5M17 10h-1.5a2 2 0 000 4H17',
  style: 'M4 20h16M7 16l5-12 5 12M9 12h6', canvas: 'M3 8V3h5M16 3h5v5M21 16v5h-5M8 21H3v-5',
  look: 'M12 3a9 9 0 110 18 9 9 0 010-18zM12 3v18M12 8l4.5-3M12 13l7.5-4M12 18l7-2.5',
  back: 'M15 18l-6-6 6-6', moveL: 'M11 17l-5-5 5-5M18 17l-5-5 5-5', moveR: 'M13 17l5-5-5-5M6 17l5-5-5-5',
  clock: 'M12 3a9 9 0 110 18 9 9 0 010-18zM12 7v5l3 2', motion: 'M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7',
  trans: 'M3 4h8v16H3zM14 4h7M14 9h7M14 14h7M14 19h7', detach: 'M12 3v11M8 10l4 4 4-4M4 20h16',
  edit: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4', move: 'M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20',
  download: 'M12 3v12M7 10l5 5 5-5M5 21h14', share: 'M4 12v7h16v-7M12 3v12M7 8l5-5 5 5',
  voice: 'M12 3l1.8 4.6L18 9.5l-4.2 1.9L12 16l-1.8-4.6L6 9.5l4.2-1.9zM19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z',
  check: 'M5 12l5 5L20 7', close: 'M6 6l12 12M18 6L6 18', refresh: 'M21 12a9 9 0 11-3-6.7L21 8M21 3v5h-5',
  file: 'M14 3H6v18h12V7zM14 3v4h4', mute: 'M11 5L6 9H2v6h4l5 4zM22 9l-6 6M16 9l6 6', zoomIn: 'M11 4a7 7 0 110 14 7 7 0 010-14zM21 21l-5-5M11 8v6M8 11h6', zoomOut: 'M11 4a7 7 0 110 14 7 7 0 010-14zM21 21l-5-5M8 11h6'
};
function icon(name, size) {
  const s = size || 22;
  if (name === 'play') return `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M7 4.6v14.8c0 .8.9 1.3 1.5.8l11-7.4c.6-.4.6-1.2 0-1.6l-11-7.4C7.9 3.3 7 3.8 7 4.6z" fill="currentColor"/></svg>`;
  if (name === 'pause') return `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1.2" fill="currentColor"/><rect x="14" y="4" width="4" height="16" rx="1.2" fill="currentColor"/></svg>`;
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${P[name] || P.plus}"/></svg>`;
}

// ===================== state =====================
const STYLE_BY_ID = Object.fromEntries(Presets.SUB_STYLES.map(s => [s.id, s]));
const LOOK_BY_ID = Object.fromEntries(Presets.LOOKS.map(l => [l.id, l]));
const RATIOS = { '9:16': [9, 16], '16:9': [16, 9], '1:1': [1, 1], '4:5': [4, 5], '4:3': [4, 3], '3:4': [3, 4], '21:9': [21, 9] };
const zeros = () => [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

function newProject() {
  return { ratio: '9:16', fit: 'contain', bg: 'black', main: [], audio: [], texts: [], defStyle: 't1_sun' };
}
const S = {
  media: new Map(), p: newProject(), sel: null, t: 0, playing: false, pps: 60,
  undo: [], redo: [], dirty: true, exporting: null, textBounds: {}, sheetSnap: false
};
const media = c => S.media.get(c.mediaId);
const clipDur = c => (c.kind === 'image' ? c.dur : c.out - c.in);

function mainLayout() {
  let t = 0;
  return S.p.main.map((clip, idx) => { const d = clipDur(clip), r = { clip, idx, start: t, dur: d }; t += d; return r; });
}
const mainEnd = () => S.p.main.reduce((a, c) => a + clipDur(c), 0);
function totalDur() {
  let d = mainEnd();
  for (const a of S.p.audio) d = Math.max(d, a.start + (a.out - a.in));
  for (const x of S.p.texts) d = Math.max(d, x.end);
  return d;
}
function mainAt(t) {
  const L = mainLayout();
  for (const r of L) if (t >= r.start && t < r.start + r.dur) return r;
  if (L.length && Math.abs(t - mainEnd()) < 1e-3) return L[L.length - 1];
  return null;
}
function audioSegments() {
  const segs = [];
  for (const r of mainLayout()) {
    const m = media(r.clip);
    if (r.clip.kind === 'video' && m && m.buffer && !r.clip.muted)
      segs.push({ clip: r.clip, buffer: m.buffer, tlStart: r.start, srcIn: r.clip.in, dur: r.dur });
  }
  for (const a of S.p.audio) {
    const m = media(a);
    if (m && m.buffer && !a.muted) segs.push({ clip: a, buffer: m.buffer, tlStart: a.start, srcIn: a.in, dur: a.out - a.in });
  }
  return segs;
}
function findItem(sel) {
  if (!sel) return null;
  const list = sel.type === 'main' ? S.p.main : sel.type === 'audio' ? S.p.audio : S.p.texts;
  return list.find(x => x.id === sel.id) || null;
}
function computeLanes(items, s, e) {
  const lanes = [], map = {};
  [...items].sort((a, b) => s(a) - s(b)).forEach(it => {
    let li = lanes.findIndex(end => end <= s(it) + 0.001);
    if (li < 0) { li = lanes.length; lanes.push(0); }
    lanes[li] = e(it); map[it.id] = li;
  });
  return { map, count: Math.max(1, lanes.length) };
}

// ===================== undo / edits =====================
function snapshot() {
  S.undo.push(JSON.stringify(S.p)); if (S.undo.length > 80) S.undo.shift(); S.redo = [];
  updateUndoBtns();
}
function edit(fn) { pause(); snapshot(); fn(); afterEdit(); }
function touchEdit() { if (!S.sheetSnap) { snapshot(); S.sheetSnap = true; } }
function afterEdit() {
  if (S.sel && !findItem(S.sel)) S.sel = null;
  S.t = clamp(S.t, 0, totalDur());
  renderTimeline(); renderDock(); requestDraw(); updateTC(); updateEmpty();
}
function undo() {
  if (!S.undo.length) return; pause();
  S.redo.push(JSON.stringify(S.p)); S.p = JSON.parse(S.undo.pop()); afterEdit(); updateUndoBtns(); layoutStage();
}
function redo() {
  if (!S.redo.length) return; pause();
  S.undo.push(JSON.stringify(S.p)); S.p = JSON.parse(S.redo.pop()); afterEdit(); updateUndoBtns(); layoutStage();
}
function updateUndoBtns() {
  $('#btnUndo').disabled = !S.undo.length; $('#btnRedo').disabled = !S.redo.length;
}

// ===================== toast =====================
let toastTimer;
function toast(msg, kind, ms) {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast show ' + (kind || '');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.className = 'toast'; }, ms || (kind === 'err' ? 5200 : 2400));
}

// ===================== audio context =====================
const Eng = { ctx: null, live: [], master: null, t0: 0, c0: 0, running: false };
function actx() {
  if (!Eng.ctx) {
    Eng.ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'playback' });
    Eng.master = AudioFX.makeMaster(Eng.ctx); Eng.master.out.connect(Eng.ctx.destination);
  }
  return Eng.ctx;
}
function engineStart(from, dest) {
  const ctx = actx(); engineStop();
  const start = ctx.currentTime + 0.08;
  Eng.live = AudioFX.schedule(ctx, audioSegments(), from, totalDur() + 0.05, start, dest || Eng.master.in);
  Eng.t0 = from; Eng.c0 = start; Eng.running = true;
}
function engineStop() { AudioFX.stopAll(Eng.live); Eng.live = []; Eng.running = false; }
const engineNow = () => Eng.t0 + Math.max(0, Eng.ctx.currentTime - Eng.c0);

// ===================== media import =====================
function kindOf(file) {
  const t = file.type || '', n = (file.name || '').toLowerCase();
  if (t.startsWith('video') || /\.(mp4|mov|m4v|webm|mkv|3gp|avi)$/.test(n)) return 'video';
  if (t.startsWith('image') || /\.(jpe?g|png|webp|gif|heic|bmp)$/.test(n)) return 'image';
  if (t.startsWith('audio') || /\.(mp3|wav|m4a|aac|ogg|opus|flac|amr)$/.test(n)) return 'audio';
  return null;
}
const waitEv = (el, ev, ms) => new Promise((res, rej) => {
  const to = setTimeout(() => { el.removeEventListener(ev, ok); rej(new Error('timeout')); }, ms || 15000);
  function ok() { clearTimeout(to); el.removeEventListener(ev, ok); res(); }
  el.addEventListener(ev, ok);
});
async function seekVideo(el, t) { el.currentTime = t; try { await waitEv(el, 'seeked', 6000); } catch (e) {} }
async function decodeFile(file) {
  const ab = await file.arrayBuffer();
  return await new Promise((res, rej) => actx().decodeAudioData(ab, res, rej));
}
function thumbFrom(src, sw, sh) {
  const th = 96, tw = Math.max(40, Math.round(th * sw / sh));
  const c = h('canvas'); c.width = tw; c.height = th;
  c.getContext('2d').drawImage(src, 0, 0, tw, th);
  return c.toDataURL('image/jpeg', 0.7);
}
async function loadMedia(file, asAudio) {
  let kind = kindOf(file);
  if (!kind) throw new Error(file.name + ': unsupported file type');
  if (asAudio && kind === 'video') kind = 'audio';
  const m = { id: uid(), name: file.name || kind, kind, file, url: URL.createObjectURL(file), duration: 0, width: 0, height: 0, buffer: null };
  if (kind === 'video') {
    const el = h('video', { muted: true, playsInline: true, preload: 'auto' });
    el.muted = true; el.setAttribute('playsinline', ''); el.src = m.url;
    $('#mediaPool').append(el);
    await waitEv(el, 'loadedmetadata', 20000).catch(() => { throw new Error(file.name + ': this video format can\'t be opened on this device'); });
    if (!isFinite(el.duration)) { el.currentTime = 1e7; await waitEv(el, 'durationchange', 8000).catch(() => {}); el.currentTime = 0; }
    m.el = el; m.duration = el.duration; m.width = el.videoWidth || 1080; m.height = el.videoHeight || 1920;
    el.addEventListener('seeked', () => { S.dirty = true; if (el._pend != null) { const p = el._pend; el._pend = null; el.currentTime = p; } });
    await seekVideo(el, Math.min(0.4, m.duration / 3));
    try { m.thumb = thumbFrom(el, m.width, m.height); } catch (e) {}
    await seekVideo(el, 0);
    if (file.size < 700 * 1024 * 1024) { try { m.buffer = await decodeFile(file); } catch (e) { m.buffer = null; } }
  } else if (kind === 'image') {
    const img = new Image(); img.src = m.url;
    await waitEv(img, 'load', 20000).catch(() => { throw new Error(file.name + ': this image can\'t be opened'); });
    m.img = img; m.width = img.naturalWidth; m.height = img.naturalHeight; m.duration = 3;
    m.thumb = thumbFrom(img, m.width, m.height);
  } else {
    try { m.buffer = await decodeFile(file); } catch (e) { throw new Error(file.name + ': this audio can\'t be decoded'); }
    m.duration = m.buffer.duration;
  }
  if (m.buffer) m.wave = AudioFX.waveform(m.buffer, kind === 'video' ? 'rgba(255,255,255,.5)' : 'rgba(255,255,255,.82)');
  S.media.set(m.id, m);
  return m;
}
function mkMain(m) {
  return { id: uid(), mediaId: m.id, kind: m.kind, in: 0, out: m.kind === 'video' ? m.duration : 0, dur: m.kind === 'image' ? 3 : 0,
    volume: 1, fx: 'none', eq: zeros(), fadeIn: 0, fadeOut: 0, look: 'none', motion: m.kind === 'image' ? 'zoomIn' : 'none', vIn: false, vOut: false, muted: false };
}
function mkAudio(m, start, extra) {
  return Object.assign({ id: uid(), mediaId: m.id, start, in: 0, out: m.duration, volume: 1, fx: 'none', eq: zeros(), fadeIn: 0, fadeOut: 0, label: m.name, tts: false }, extra || {});
}
async function importFiles(files, target) {
  files = [...files]; if (!files.length) return;
  pause();
  const added = [];
  for (let i = 0; i < files.length; i++) {
    toast(files.length > 1 ? `Importing ${i + 1} of ${files.length}…` : 'Importing…', '', 60000);
    try { added.push(await loadMedia(files[i], target === 'audio')); }
    catch (e) { toast(e.message, 'err'); await new Promise(r => setTimeout(r, 1200)); }
  }
  if (!added.length) return;
  const wasEmpty = !S.p.main.length;
  edit(() => {
    let insertAt = S.p.main.length;
    const cur = mainAt(S.t);
    if (cur && target !== 'audio') insertAt = cur.idx + 1;
    let at = S.t;
    for (const m of added) {
      if (m.kind === 'audio' || target === 'audio') {
        const a = mkAudio(m, at); S.p.audio.push(a); at += a.out;
      } else { S.p.main.splice(insertAt++, 0, mkMain(m)); }
    }
  });
  if (wasEmpty) autoRatio();
  toast(added.length === 1 ? 'Added ' + added[0].name : `Added ${added.length} items`);
}
function autoRatio() {
  const first = S.p.main[0]; if (!first) return;
  const m = media(first); if (!m || !m.width) return;
  const r = m.width / m.height;
  let best = '9:16', bd = 9;
  for (const k of ['9:16', '16:9', '1:1', '4:5', '4:3', '3:4']) { const [a, b] = RATIOS[k]; const d = Math.abs(Math.log(r / (a / b))); if (d < bd) { bd = d; best = k; } }
  S.p.ratio = best; layoutStage();
}

// ===================== playback =====================
function play() {
  if (S.playing || S.exporting) return;
  const d = totalDur(); if (d <= 0) return;
  if (S.t >= d - 0.05) S.t = 0;
  actx().resume();
  engineStart(S.t); S.playing = true;
  $('#btnPlay').innerHTML = icon('pause', 26);
}
function pause() {
  if (!S.playing) return;
  S.playing = false; engineStop();
  for (const m of S.media.values()) if (m.el && !m.el.paused) m.el.pause();
  $('#btnPlay').innerHTML = icon('play', 26);
  syncVideos(S.t, false); requestDraw();
}
function refreshPlayback() { if (S.playing) { const t = engineNow(); S.t = t; engineStart(t); } }
function seek(t, fromScroll) {
  S.t = clamp(t, 0, totalDur());
  if (S.playing) engineStart(S.t);
  else syncVideos(S.t, false);
  if (!fromScroll) scrollToTime();
  updateTC(); requestDraw(); renderDockState();
}
function requestDraw() { S.dirty = true; }

function syncVideos(t, playing) {
  const cur = mainAt(t);
  const curM = cur && cur.clip.kind === 'video' ? media(cur.clip) : null;
  for (const m of S.media.values()) if (m.el && m !== curM && !m.el.paused) m.el.pause();
  if (curM && curM.el) {
    const el = curM.el, target = cur.clip.in + (t - cur.start);
    if (playing) {
      if (el.paused) el.play().catch(() => {});
      if (Math.abs(el.currentTime - target) > 0.3 && !el.seeking) el.currentTime = target;
      const L = mainLayout(), nx = L[cur.idx + 1];
      if (nx && nx.clip.kind === 'video' && nx.clip.mediaId !== cur.clip.mediaId && cur.start + cur.dur - t < 0.8) {
        const ne = media(nx.clip).el;
        if (ne && ne.paused && !ne.seeking && Math.abs(ne.currentTime - nx.clip.in) > 0.05) ne.currentTime = nx.clip.in;
      }
    } else {
      if (!el.paused) el.pause();
      if (Math.abs(el.currentTime - target) > 0.015) {
        if (el.seeking) el._pend = target; else el.currentTime = target;
      }
    }
  }
}

// ===================== compositor =====================
function canvasSize(longSide) {
  const [a, b] = RATIOS[S.p.ratio] || [9, 16];
  let W, H;
  if (a >= b) { W = longSide; H = Math.round(longSide * b / a); } else { H = longSide; W = Math.round(longSide * a / b); }
  return [W - (W % 2), H - (H % 2)];
}
function drawFit(g, src, sw, sh, W, H, mode, scale, dx, dy) {
  const r = mode === 'cover' ? Math.max(W / sw, H / sh) : Math.min(W / sw, H / sh);
  const w = sw * r * (scale || 1), hh = sh * r * (scale || 1);
  g.drawImage(src, (W - w) / 2 + (dx || 0) * W, (H - hh) / 2 + (dy || 0) * H, w, hh);
}
const BG_COLORS = { black: '#000', white: '#fff', ink: '#14182A', plum: '#2A1433', forest: '#0F2A22', sand: '#E9DCC6', rose: '#F3C6D3' };

function drawFrame(g, W, H, t, opts) {
  opts = opts || {};
  g.save(); g.filter = 'none'; g.globalAlpha = 1;
  g.fillStyle = BG_COLORS[S.p.bg] || '#000'; g.fillRect(0, 0, W, H);
  const cur = mainAt(t);
  if (cur) {
    const m = media(cur.clip);
    const src = m && (m.kind === 'video' ? m.el : m.img);
    const ready = src && (m.kind === 'image' || src.readyState >= 2);
    if (ready) {
      const look = (LOOK_BY_ID[cur.clip.look] || {}).f || 'none';
      if (S.p.bg === 'blur') {
        g.filter = `blur(${Math.round(Math.min(W, H) * 0.04)}px) brightness(.6)`;
        drawFit(g, src, m.width, m.height, W, H, 'cover', 1.2); g.filter = 'none';
      }
      let sc = 1, dx = 0, dy = 0;
      if (cur.clip.kind === 'image') {
        const k = clamp((t - cur.start) / Math.max(0.1, cur.dur), 0, 1);
        const mo = cur.clip.motion;
        if (mo === 'zoomIn') sc = 1 + 0.14 * k;
        else if (mo === 'zoomOut') sc = 1.14 - 0.14 * k;
        else if (mo === 'panL') { sc = 1.18; dx = 0.07 - 0.14 * k; }
        else if (mo === 'panR') { sc = 1.18; dx = -0.07 + 0.14 * k; }
        else if (mo === 'panU') { sc = 1.18; dy = 0.06 - 0.12 * k; }
      }
      if (look !== 'none') g.filter = look;
      drawFit(g, src, m.width, m.height, W, H, S.p.fit, sc, dx, dy);
      g.filter = 'none';
      const local = t - cur.start;
      let fade = 0;
      if (cur.clip.vIn && local < 0.6) fade = Math.max(fade, 1 - local / 0.6);
      if (cur.clip.vOut && cur.dur - local < 0.6) fade = Math.max(fade, 1 - (cur.dur - local) / 0.6);
      if (fade > 0) { g.globalAlpha = fade; g.fillStyle = '#000'; g.fillRect(0, 0, W, H); g.globalAlpha = 1; }
    }
  }
  if (opts.subs !== false) drawTexts(g, W, H, t, opts.preview);
  g.restore();
}

// ===================== subtitle renderer =====================
function resolveStyle(tx) { return Object.assign({}, STYLE_BY_ID[tx.styleId] || Presets.SUB_STYLES[0], tx.ov || {}); }
function textWords(tx) {
  const raw = (tx.text || '').trim().split(/\s+/).filter(Boolean);
  if (tx.words && tx.words.length === raw.length) return tx.words.map((w, i) => ({ w: raw[i], s: w.s, e: w.e }));
  const total = raw.reduce((a, w) => a + w.length + 1, 0) || 1, span = tx.end - tx.start;
  let acc = 0;
  return raw.map(w => { const s = tx.start + span * acc / total; acc += w.length + 1; return { w, s, e: tx.start + span * acc / total }; });
}
function rrect(g, x, y, w, hh, r) {
  r = Math.min(r, hh / 2, w / 2); g.beginPath();
  g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + hh, r); g.arcTo(x + w, y + hh, x, y + hh, r);
  g.arcTo(x, y + hh, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function drawTexts(g, W, H, t, preview) {
  if (preview) S.textBounds = {};
  for (const tx of S.p.texts) if (t >= tx.start && t < tx.end) drawSubtitle(g, W, H, tx, t, preview);
}
function drawSubtitle(g, W, H, tx, t, preview) {
  const st = resolveStyle(tx), unit = Math.min(W, H);
  const fs = st.size * unit * (tx.scale || 1);
  const all = textWords(tx); if (!all.length) return;
  let ai = -1; for (let i = 0; i < all.length; i++) if (t >= all[i].s) ai = i;
  let words = st.single ? [all[Math.max(0, ai)]] : all;
  const activeIdx = st.single ? 0 : ai;
  const age = t - tx.start, remain = tx.end - t, span = tx.end - tx.start;
  // typewriter reveal
  let reveal = Infinity;
  if (st.anim === 'type') { const total = words.reduce((a, w) => a + w.w.length + 1, 0); reveal = Math.floor(total * clamp(age / Math.max(0.35, span * 0.55), 0, 1)); }
  g.save();
  g.font = `${st.italic ? 'italic ' : ''}${st.weight} ${fs}px "${st.font}", "Manrope", sans-serif`;
  try { g.letterSpacing = ((st.ls || 0) * fs).toFixed(1) + 'px'; } catch (e) {}
  g.textBaseline = 'middle'; g.textAlign = 'left'; g.lineJoin = 'round'; g.miterLimit = 2;
  const disp = w => (st.upper ? w.toLocaleUpperCase() : w);
  const space = g.measureText(' ').width, maxW = W * 0.84;
  const lines = []; let line = [], lw = 0;
  words.forEach((w, i) => {
    const ww = g.measureText(disp(w.w)).width;
    if (line.length && lw + space + ww > maxW) { lines.push({ items: line, w: lw }); line = []; lw = 0; }
    lw += (line.length ? space : 0) + ww; line.push({ ...w, i, ww });
  });
  if (line.length) lines.push({ items: line, w: lw });
  const lineH = fs * 1.22, blockH = lines.length * lineH;
  let alpha = 1, sc = 1, oy = 0;
  const k = clamp(age / 0.24, 0, 1);
  if (st.anim === 'pop' || st.anim === 'bounce') sc = 0.72 + 0.28 * backOut(k);
  else if (st.anim === 'slide') { oy = (1 - ease(k)) * fs * 0.7; alpha = k; }
  else if (st.anim === 'fade') alpha = Math.min(1, age / 0.22, remain / 0.18);
  if (st.single && ai >= 0) { const wa = t - all[ai].s; sc = 0.78 + 0.22 * backOut(clamp(wa / 0.16, 0, 1)); }
  const cx = tx.x * W, cy = tx.y * H, top = cy - blockH / 2 + oy;
  g.globalAlpha = clamp(alpha, 0, 1);
  g.translate(cx, cy); g.scale(sc, sc); g.translate(-cx, -cy);
  const pad = st.bg ? st.bg.pad * fs : 0;
  let maxLW = 0, chars = 0;
  lines.forEach((ln, li) => {
    maxLW = Math.max(maxLW, ln.w);
    const y = top + li * lineH + lineH / 2;
    let x = cx - ln.w / 2;
    if (st.bg) {
      g.save(); g.shadowColor = 'transparent'; g.fillStyle = st.bg.c;
      rrect(g, x - pad, y - lineH / 2 - pad * 0.35 + (li ? pad * 0.35 : 0), ln.w + pad * 2, lineH + pad * (li ? 0.35 : 0.7) + (li === lines.length - 1 ? pad * 0.35 : 0), st.bg.r * fs * 1.4);
      g.fill(); g.restore();
    }
    for (const w of ln.items) {
      let s = disp(w.w);
      if (chars >= reveal) break;
      if (chars + s.length > reveal) s = s.slice(0, reveal - chars);
      chars += w.w.length + 1;
      const active = w.i === activeIdx && ai >= 0;
      let fill = st.fill || '#fff';
      if (active && st.hl) fill = st.hl;
      if (active && st.hlFillWord) fill = st.hlFillWord;
      let wsc = 1;
      if (active && (st.hlScale || st.anim === 'bounce')) { const wk = clamp((t - w.s) / 0.14, 0, 1); wsc = 1 + ((st.hlScale || 1.1) - 1) * (wk < 1 ? backOut(wk) : 1); }
      g.save();
      const wx = x + w.ww / 2;
      g.translate(wx, y); g.scale(wsc, wsc); g.translate(-wx, -y);
      if (active && st.hlBg) {
        g.save(); g.fillStyle = st.hlBg; rrect(g, x - fs * 0.14, y - fs * 0.62, g.measureText(s).width + fs * 0.28, fs * 1.24, fs * 0.18); g.fill(); g.restore();
        fill = st.hlFill || '#000';
      }
      let fillStyle = fill;
      if (st.grad && !(active && (st.hl || st.hlBg))) { const gr = g.createLinearGradient(0, y - fs / 2, 0, y + fs / 2); gr.addColorStop(0, st.grad[0]); gr.addColorStop(1, st.grad[1]); fillStyle = gr; }
      const setShadow = () => {
        if (st.glow) { g.shadowColor = st.glow; g.shadowBlur = fs * 0.45; g.shadowOffsetX = 0; g.shadowOffsetY = 0; }
        else if (st.shadow) { g.shadowColor = st.shadow.c; g.shadowBlur = st.shadow.b * fs / 70; g.shadowOffsetX = st.shadow.x * fs / 70; g.shadowOffsetY = st.shadow.y * fs / 70; }
      };
      const noShadow = () => { g.shadowColor = 'transparent'; g.shadowBlur = 0; g.shadowOffsetX = 0; g.shadowOffsetY = 0; };
      const hasStroke = st.stroke && st.strokeW && !(active && st.hlBg);
      if (hasStroke) { setShadow(); g.strokeStyle = st.stroke; g.lineWidth = st.strokeW * fs * 2; g.strokeText(s, x, y); noShadow(); }
      else setShadow();
      g.fillStyle = fillStyle; g.fillText(s, x, y);
      if (st.glow) g.fillText(s, x, y);
      g.restore();
      x += w.ww + space;
    }
  });
  if (st.anim === 'type' && st.cursor && reveal < Infinity && Math.floor(t * 2.4) % 2 === 0) {
    g.fillStyle = st.cursor; const last = lines[lines.length - 1];
    g.fillRect(cx + last.w / 2 + fs * 0.12, top + blockH - lineH + fs * 0.12, fs * 0.09, lineH - fs * 0.24);
  }
  g.restore();
  if (preview) {
    const bw = (maxLW + pad * 2 + fs * 0.3) * sc, bh = (blockH + pad) * sc;
    S.textBounds[tx.id] = { x: cx - bw / 2, y: cy + oy * sc - bh / 2, w: bw, h: bh };
  }
}

// ===================== preview stage =====================
let PV = { cv: null, g: null, W: 540, H: 960 };
function layoutStage() {
  const stage = $('#stage'), cv = $('#preview');
  const sw = stage.clientWidth - 16, sh = stage.clientHeight - 16;
  const [a, b] = RATIOS[S.p.ratio] || [9, 16];
  let w = sw, hh = sw * b / a; if (hh > sh) { hh = sh; w = sh * a / b; }
  cv.style.width = Math.max(10, Math.floor(w)) + 'px'; cv.style.height = Math.max(10, Math.floor(hh)) + 'px';
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const long = clamp(Math.round(Math.max(w, hh) * dpr), 320, 1280);
  const [W, H] = canvasSize(long);
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
  PV = { cv, g: cv.getContext('2d'), W, H };
  requestDraw();
}
function drawPreview() {
  drawFrame(PV.g, PV.W, PV.H, S.t, { preview: true });
  if (S.sel && S.sel.type === 'text') {
    const b = S.textBounds[S.sel.id];
    if (b) {
      const g = PV.g; g.save(); g.strokeStyle = '#FFC24B'; g.lineWidth = Math.max(2, PV.W / 300); g.setLineDash([PV.W / 60, PV.W / 90]);
      g.strokeRect(b.x, b.y, b.w, b.h); g.restore();
    }
  }
}
function updateTC() { $('#tc').textContent = fmt(S.t); $('#tcDur').textContent = fmt(totalDur()); }
function updateEmpty() { $('#emptyState').hidden = S.p.main.length > 0 || S.p.audio.length > 0 || S.p.texts.length > 0; }

function initPreviewGestures() {
  const cv = $('#preview');
  const ptrs = new Map(); let drag = null;
  const toCanvas = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * PV.W, y: (e.clientY - r.top) / r.height * PV.H }; };
  cv.addEventListener('pointerdown', e => {
    ptrs.set(e.pointerId, e);
    const p = toCanvas(e);
    if (ptrs.size === 2 && drag && drag.tx) {
      const [a, b] = [...ptrs.values()]; drag.pinch = { d: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), s: drag.tx.scale || 1 }; return;
    }
    let hit = null;
    for (const tx of [...S.p.texts].reverse()) {
      const bb = S.textBounds[tx.id];
      if (bb && p.x >= bb.x - 10 && p.x <= bb.x + bb.w + 10 && p.y >= bb.y - 10 && p.y <= bb.y + bb.h + 10) { hit = tx; break; }
    }
    if (hit) {
      pause(); cv.setPointerCapture(e.pointerId);
      if (!S.sel || S.sel.id !== hit.id) { S.sel = { type: 'text', id: hit.id }; renderTimeline(); renderDock(); }
      drag = { tx: hit, p0: p, x0: hit.x, y0: hit.y, moved: false };
    } else { drag = null; }
  });
  cv.addEventListener('pointermove', e => {
    if (!ptrs.has(e.pointerId)) return; ptrs.set(e.pointerId, e);
    if (!drag) return;
    if (drag.pinch && ptrs.size === 2) {
      const [a, b] = [...ptrs.values()]; const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      if (!drag.moved) { snapshot(); drag.moved = true; }
      drag.tx.scale = clamp(drag.pinch.s * d / drag.pinch.d, 0.3, 4); requestDraw(); return;
    }
    const p = toCanvas(e);
    const dx = (p.x - drag.p0.x) / PV.W, dy = (p.y - drag.p0.y) / PV.H;
    if (!drag.moved && Math.hypot(dx * PV.W, dy * PV.H) < 6) return;
    if (!drag.moved) { snapshot(); drag.moved = true; }
    let nx = clamp(drag.x0 + dx, 0.05, 0.95), ny = clamp(drag.y0 + dy, 0.04, 0.96);
    if (Math.abs(nx - 0.5) < 0.015) nx = 0.5;
    drag.tx.x = nx; drag.tx.y = ny; requestDraw();
  });
  const up = e => { ptrs.delete(e.pointerId); if (ptrs.size < 2 && drag) drag.pinch = null; if (!ptrs.size) drag = null; };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  cv.addEventListener('click', e => {
    if (drag) return;
    const p = toCanvas(e); let hit = false;
    for (const id in S.textBounds) { const bb = S.textBounds[id]; if (p.x >= bb.x && p.x <= bb.x + bb.w && p.y >= bb.y && p.y <= bb.y + bb.h) hit = true; }
    if (!hit && S.sel && S.sel.type === 'text') { S.sel = null; renderTimeline(); renderDock(); requestDraw(); }
  });
}

// ===================== timeline =====================
const TL = { el: null, inner: null, pad: 0 };
const ROW = { ruler: 22, main: 58, text: 32, audio: 42, gap: 6 };

function scrollToTime() {
  const x = S.t * S.pps;
  if (Math.abs(TL.el.scrollLeft - x) >= 0.5) TL.el.scrollLeft = x;
}
function renderTimeline() {
  const tl = TL.el, inner = TL.inner;
  const vw = tl.clientWidth; TL.pad = vw / 2;
  const dur = totalDur(), pps = S.pps;
  inner.style.width = (TL.pad * 2 + Math.max(dur, 0.1) * pps) + 'px';
  inner.style.setProperty('--pad', TL.pad + 'px');
  inner.innerHTML = '';
  // ruler
  const ruler = h('div', { class: 'ruler', style: `height:${ROW.ruler}px` });
  const steps = [0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];
  const step = steps.find(s => s * pps >= 64) || 600;
  const showEnd = dur + vw / 2 / pps;
  for (let s = 0; s <= showEnd; s += step) {
    ruler.append(h('span', { class: 'tick', style: `left:${TL.pad + s * pps}px` }, step < 1 ? fmt(s).slice(1) : fmt(s).slice(0, 5)));
    ruler.append(h('i', { class: 'dot', style: `left:${TL.pad + (s + step / 2) * pps}px` }));
  }
  inner.append(ruler);
  // main track
  const mainRow = h('div', { class: 'row main', style: `height:${ROW.main}px` });
  for (const r of mainLayout()) mainRow.append(clipEl('main', r.clip, r.start, r.dur));
  if (!S.p.main.length) mainRow.append(h('button', { class: 'ghost', style: `left:${TL.pad}px`, onclick: () => pickMedia() }, h('span', { html: icon('plus', 16) }), 'Add video or photos'));
  inner.append(mainRow);
  // text lanes
  const tl2 = computeLanes(S.p.texts, x => x.start, x => x.end);
  const textRows = [];
  for (let i = 0; i < tl2.count; i++) { const r = h('div', { class: 'row text', style: `height:${ROW.text}px` }); textRows.push(r); inner.append(r); }
  for (const x of S.p.texts) textRows[tl2.map[x.id]].append(clipEl('text', x, x.start, x.end - x.start));
  if (!S.p.texts.length) textRows[0].append(h('button', { class: 'ghost small', style: `left:${TL.pad}px`, onclick: () => openSheet('addText') }, h('span', { html: icon('text', 14) }), 'Add text'));
  // audio lanes
  const al = computeLanes(S.p.audio, x => x.start, x => x.start + x.out - x.in);
  const audRows = [];
  for (let i = 0; i < al.count; i++) { const r = h('div', { class: 'row audio', style: `height:${ROW.audio}px` }); audRows.push(r); inner.append(r); }
  for (const a of S.p.audio) audRows[al.map[a.id]].append(clipEl('audio', a, a.start, a.out - a.in));
  if (!S.p.audio.length) audRows[0].append(h('button', { class: 'ghost small', style: `left:${TL.pad}px`, onclick: () => openSheet('addAudio') }, h('span', { html: icon('music', 14) }), 'Add audio'));
  tl.scrollLeft = S.t * pps;
}

function clipEl(type, item, start, dur) {
  const pps = S.pps, sel = S.sel && S.sel.id === item.id;
  const el = h('div', { class: 'clip ' + type + (sel ? ' sel' : '') + (item.tts ? ' tts' : '') + (type === 'main' ? ' k-' + item.kind : ''), 'data-id': item.id, 'data-type': type });
  styleClipEl(el, type, item, start, dur);
  if (type === 'main') {
    const m = media(item);
    const lab = h('span', { class: 'lab' }, fmt(dur).replace(/^00:/, '') + 's');
    if (item.muted && item.kind === 'video') lab.prepend(h('b', { html: icon('mute', 11) }));
    el.append(lab);
    if (m && m.kind === 'image') el.append(h('span', { class: 'kind', html: icon('media', 11) }));
  } else if (type === 'text') {
    el.append(h('span', { class: 'lab' }, item.text || ' '));
  } else {
    el.append(h('span', { class: 'lab' }, (item.tts ? 'Voice: ' : '') + (item.label || 'Audio')));
  }
  if (sel) { el.append(h('i', { class: 'h hl', 'data-side': 'l' })); el.append(h('i', { class: 'h hr', 'data-side': 'r' })); }
  return el;
}
function styleClipEl(el, type, item, start, dur) {
  const pps = S.pps;
  el.style.left = (TL.pad + start * pps) + 'px';
  el.style.width = Math.max(4, dur * pps - 2) + 'px';
  const m = type !== 'text' ? media(item) : null;
  if (type === 'main' && m && m.thumb) {
    el.style.backgroundImage = `url(${m.thumb})`;
  } else if (type === 'audio' && m && m.wave) {
    el.style.backgroundImage = `url(${m.wave})`;
    el.style.backgroundSize = `${m.duration * pps}px 70%`;
    el.style.backgroundPosition = `${-item.in * pps}px 60%`;
  }
}

// snapping candidates
function snapTimes(excludeId) {
  const s = [0, S.t, mainEnd()];
  for (const r of mainLayout()) s.push(r.start);
  for (const a of S.p.audio) if (a.id !== excludeId) s.push(a.start, a.start + a.out - a.in);
  for (const x of S.p.texts) if (x.id !== excludeId) s.push(x.start, x.end);
  return s;
}
function snap(v, cands) {
  const th = 10 / S.pps; let best = v, bd = th;
  for (const c of cands) { const d = Math.abs(c - v); if (d < bd) { bd = d; best = c; } }
  return best;
}

function initTimeline() {
  TL.el = $('#tl'); TL.inner = $('#tlInner');
  let raf = 0;
  TL.el.addEventListener('scroll', () => {
    if (Math.abs(TL.el.scrollLeft - S.t * S.pps) < 1.5) return; // programmatic
    if (S.playing) pause();
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(() => seek(TL.el.scrollLeft / S.pps, true));
  }, { passive: true });
  TL.el.addEventListener('pointerdown', () => { if (S.playing) pause(); });

  // tap to select / deselect
  TL.inner.addEventListener('click', e => {
    const c = e.target.closest('.clip');
    if (c) {
      const type = c.dataset.type, id = c.dataset.id;
      if (S.sel && S.sel.id === id) return;
      S.sel = { type, id };
      if (type === 'text' || type === 'audio') {
        const it = findItem(S.sel); const st = it.start, en = type === 'text' ? it.end : it.start + it.out - it.in;
        if (S.t < st || S.t >= en) seek(st + 0.01);
      } else {
        const r = mainLayout().find(x => x.clip.id === id);
        if (r && (S.t < r.start || S.t >= r.start + r.dur)) seek(r.start + 0.01);
      }
      renderTimeline(); renderDock(); requestDraw();
    } else if (!e.target.closest('.ghost') && S.sel) { S.sel = null; renderTimeline(); renderDock(); requestDraw(); }
  });

  // drag handles / move selected clip
  TL.inner.addEventListener('pointerdown', e => {
    const c = e.target.closest('.clip.sel'); if (!c) return;
    const side = e.target.dataset.side || null;
    const type = c.dataset.type, item = findItem({ type, id: c.dataset.id }); if (!item) return;
    if (!side && type === 'main') return;
    e.preventDefault(); e.stopPropagation(); pause();
    const x0 = e.clientX, orig = JSON.parse(JSON.stringify(item));
    const cands = snapTimes(item.id);
    const startTl = type === 'main' ? mainLayout().find(r => r.clip.id === item.id).start : item.start;
    const m = type !== 'text' ? media(item) : null;
    let snapped = false;
    const mv = ev => {
      const d = (ev.clientX - x0) / S.pps;
      if (!snapped && Math.abs(ev.clientX - x0) > 3) { snapshot(); snapped = true; }
      if (!snapped) return;
      if (type === 'main') {
        if (item.kind === 'image') {
          item.dur = side === 'r' ? Math.max(0.3, orig.dur + d) : Math.max(0.3, orig.dur - d);
          if (side === 'r') item.dur = Math.max(0.3, snap(startTl + item.dur, cands) - startTl);
        } else if (side === 'l') item.in = clamp(orig.in + d, 0, orig.out - 0.15);
        else { item.out = clamp(orig.out + d, orig.in + 0.15, m.duration); const e2 = snap(startTl + item.out - item.in, cands); item.out = clamp(item.in + e2 - startTl, orig.in + 0.15, m.duration); }
        styleClipEl(c, 'main', item, startTl, clipDur(item));
        if (side === 'l' && m && m.thumb) c.style.backgroundPosition = `${-(item.in - orig.in) * S.pps}px 0`;
      } else if (type === 'audio') {
        if (side === 'l') { item.in = clamp(orig.in + d, 0, orig.out - 0.15); item.start = orig.start + (item.in - orig.in); const sn = snap(item.start, cands); item.in = clamp(item.in + sn - item.start, 0, orig.out - 0.15); item.start = orig.start + (item.in - orig.in); }
        else if (side === 'r') { item.out = clamp(orig.out + d, orig.in + 0.15, m.duration); const e2 = snap(item.start + item.out - item.in, cands); item.out = clamp(item.in + e2 - item.start, orig.in + 0.15, m.duration); }
        else { item.start = Math.max(0, snap(orig.start + d, cands)); const end = item.start + item.out - item.in; const se = snap(end, cands); if (se !== end) item.start = Math.max(0, se - (item.out - item.in)); }
        styleClipEl(c, 'audio', item, item.start, item.out - item.in);
        if (!side && item.tts) { const dd = item.start - orig.start; S.p.texts.forEach(x => { if (x.linkId === item.id) { if (x._o == null) x._o = [x.start, x.end, x.words ? x.words.map(w => [w.s, w.e]) : null]; x.start = x._o[0] + dd; x.end = x._o[1] + dd; if (x.words && x._o[2]) x.words.forEach((w, i) => { w.s = x._o[2][i][0] + dd; w.e = x._o[2][i][1] + dd; }); } }); }
      } else {
        if (side === 'l') item.start = clamp(snap(orig.start + d, cands), 0, orig.end - 0.15);
        else if (side === 'r') item.end = Math.max(orig.start + 0.15, snap(orig.end + d, cands));
        else { const len = orig.end - orig.start; item.start = Math.max(0, snap(orig.start + d, cands)); item.end = item.start + len; const se = snap(item.end, cands); if (se !== item.end) { item.end = se; item.start = Math.max(0, se - len); } const dd = item.start - orig.start; if (item.words && orig.words) item.words.forEach((w, i) => { w.s = orig.words[i].s + dd; w.e = orig.words[i].e + dd; }); }
        styleClipEl(c, 'text', item, item.start, item.end - item.start);
      }
      requestDraw();
    };
    const up = () => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up);
      S.p.texts.forEach(x => delete x._o);
      if (snapped) afterEdit();
    };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
  });

  // pinch zoom
  let pz = null;
  TL.el.addEventListener('touchstart', e => { if (e.touches.length === 2) { const [a, b] = e.touches; pz = { d: Math.abs(a.clientX - b.clientX) || 1, pps: S.pps }; } }, { passive: true });
  TL.el.addEventListener('touchmove', e => {
    if (pz && e.touches.length === 2) {
      e.preventDefault(); const [a, b] = e.touches;
      setZoom(pz.pps * (Math.abs(a.clientX - b.clientX) || 1) / pz.d);
    }
  }, { passive: false });
  TL.el.addEventListener('touchend', e => { if (e.touches.length < 2) pz = null; });
  TL.el.addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); setZoom(S.pps * (e.deltaY < 0 ? 1.15 : 0.87)); } }, { passive: false });
}
let zoomRaf = 0;
function setZoom(p) {
  S.pps = clamp(p, 6, 600);
  cancelAnimationFrame(zoomRaf); zoomRaf = requestAnimationFrame(renderTimeline);
}

// ===================== split / delete / duplicate =====================
function splitSelected() {
  let sel = S.sel;
  if (!sel) { const r = mainAt(S.t); if (r) sel = { type: 'main', id: r.clip.id }; }
  const it = findItem(sel); if (!it) return toast('Select a clip to split');
  const t = S.t;
  if (sel.type === 'main') {
    const r = mainLayout().find(x => x.clip.id === it.id), o = t - r.start;
    if (o < 0.1 || r.dur - o < 0.1) return toast('Move the playhead inside the clip to split it');
    edit(() => {
      const b = JSON.parse(JSON.stringify(it)); b.id = uid();
      if (it.kind === 'image') { b.dur = it.dur - o; it.dur = o; } else { it.out = it.in + o; b.in = it.out; }
      it.vOut = false; b.vIn = false; it.fadeOut = 0; b.fadeIn = 0;
      S.p.main.splice(r.idx + 1, 0, b);
    });
  } else if (sel.type === 'audio') {
    const o = t - it.start, len = it.out - it.in;
    if (o < 0.1 || len - o < 0.1) return toast('Move the playhead inside the clip to split it');
    edit(() => { const b = JSON.parse(JSON.stringify(it)); b.id = uid(); it.out = it.in + o; b.in = it.out; b.start = t; it.fadeOut = 0; b.fadeIn = 0; S.p.audio.push(b); });
  } else {
    if (t - it.start < 0.1 || it.end - t < 0.1) return toast('Move the playhead inside the text to split it');
    edit(() => {
      const words = textWords(it); const b = JSON.parse(JSON.stringify(it)); b.id = uid();
      const A = words.filter(w => w.s < t), B = words.filter(w => w.s >= t);
      if (A.length && B.length) {
        it.text = A.map(w => w.w).join(' '); b.text = B.map(w => w.w).join(' ');
        it.words = A.map(w => ({ s: w.s, e: w.e })); b.words = B.map(w => ({ s: w.s, e: w.e }));
      }
      b.start = t; it.end = t; S.p.texts.push(b);
    });
  }
}
function deleteSelected() {
  const sel = S.sel; if (!sel) return;
  edit(() => {
    if (sel.type === 'main') S.p.main = S.p.main.filter(x => x.id !== sel.id);
    else if (sel.type === 'audio') S.p.audio = S.p.audio.filter(x => x.id !== sel.id);
    else S.p.texts = S.p.texts.filter(x => x.id !== sel.id);
    S.sel = null;
  });
}
function duplicateSelected() {
  const it = findItem(S.sel); if (!it) return;
  edit(() => {
    const b = JSON.parse(JSON.stringify(it)); b.id = uid();
    if (S.sel.type === 'main') S.p.main.splice(S.p.main.indexOf(it) + 1, 0, b);
    else if (S.sel.type === 'audio') { b.start = it.start + it.out - it.in; b.tts = false; S.p.audio.push(b); }
    else { const len = it.end - it.start; b.start = it.end; b.end = it.end + len; if (b.words) b.words.forEach(w => { w.s += len; w.e += len; }); b.linkId = null; S.p.texts.push(b); }
    S.sel = { type: S.sel.type, id: b.id };
  });
}
function moveMain(dir) {
  const it = findItem(S.sel); if (!it) return;
  const i = S.p.main.indexOf(it), j = i + dir;
  if (j < 0 || j >= S.p.main.length) return;
  edit(() => { S.p.main.splice(i, 1); S.p.main.splice(j, 0, it); });
  const r = mainLayout().find(x => x.clip.id === it.id); seek(r.start + 0.01);
}
function detachAudio() {
  const it = findItem(S.sel); if (!it || it.kind !== 'video') return;
  const m = media(it); if (!m.buffer) return toast('This video has no readable audio track', 'err');
  const r = mainLayout().find(x => x.clip.id === it.id);
  edit(() => {
    const a = mkAudio(m, r.start, { in: it.in, out: it.out, volume: it.volume, fx: it.fx, eq: [...it.eq], fadeIn: it.fadeIn, fadeOut: it.fadeOut, label: 'Audio from ' + m.name });
    S.p.audio.push(a); it.muted = true; S.sel = { type: 'audio', id: a.id };
  });
  toast('Audio moved to its own track');
}

// ===================== docks =====================
const MAIN_TOOLS = [
  ['media', 'Media', () => pickMedia()], ['music', 'Audio', () => openSheet('addAudio')], ['text', 'Text', () => openSheet('addText')],
  ['voice', 'AI voice', () => openSheet('tts')], ['cc', 'Captions', () => openSheet('captions')], ['style', 'Styles', () => openSheet('style', { all: true })],
  ['canvas', 'Format', () => openSheet('canvas')], ['scissors', 'Split', () => splitSelected()]
];
function ctxTools(sel, it) {
  const T = [['back', 'Back', () => { S.sel = null; renderTimeline(); renderDock(); requestDraw(); }]];
  if (sel.type === 'main') {
    T.push(['scissors', 'Split', splitSelected]);
    if (it.kind === 'video') T.push(['volume', 'Volume', () => openSheet('volume')], ['fx', 'Voice FX', () => openSheet('fx')], ['eq', 'Equalizer', () => openSheet('eq')], ['detach', 'Extract audio', detachAudio]);
    else T.push(['clock', 'Duration', () => openSheet('duration')], ['motion', 'Motion', () => openSheet('motion')]);
    T.push(['look', 'Filters', () => openSheet('look')], ['trans', 'Fades', () => openSheet('trans')], ['moveL', 'Move left', () => moveMain(-1)], ['moveR', 'Move right', () => moveMain(1)]);
  } else if (sel.type === 'audio') {
    T.push(['scissors', 'Split', splitSelected], ['volume', 'Volume', () => openSheet('volume')], ['fx', 'Voice FX', () => openSheet('fx')], ['eq', 'Equalizer', () => openSheet('eq')]);
  } else {
    T.push(['edit', 'Edit text', () => openSheet('editText')], ['style', 'Style', () => openSheet('style')], ['move', 'Position', () => openSheet('position')], ['scissors', 'Split', splitSelected]);
  }
  T.push(['copy', 'Duplicate', duplicateSelected], ['trash', 'Delete', deleteSelected]);
  return T;
}
function renderDock() {
  const dock = $('#dock'); dock.innerHTML = '';
  const it = findItem(S.sel);
  const tools = it ? ctxTools(S.sel, it) : MAIN_TOOLS;
  dock.classList.toggle('ctx', !!it);
  for (const [ic, label, fn] of tools) {
    const b = h('button', { class: 'tool' + (ic === 'trash' ? ' danger' : ''), onclick: fn }, h('span', { class: 'ti', html: icon(ic) }), h('span', { class: 'tlab' }, label));
    dock.append(b);
  }
}
function renderDockState() {}

// ===================== main loop =====================
function loop() {
  requestAnimationFrame(loop);
  if (S.exporting) { exportTick(); return; }
  if (S.playing) {
    S.t = engineNow();
    const d = totalDur();
    if (S.t >= d) { S.t = d; pause(); }
    syncVideos(S.t, true); scrollToTime(); updateTC(); drawPreview();
  } else if (S.dirty) { S.dirty = false; drawPreview(); }
}
