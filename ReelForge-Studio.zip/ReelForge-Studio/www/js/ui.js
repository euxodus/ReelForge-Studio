/* ReelForge Studio — panels, AI voice, captions, export, init */
'use strict';

// ===================== small persisted settings =====================
const store = {
  get(k, d) { try { const v = localStorage.getItem('rf.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('rf.' + k, JSON.stringify(v)); } catch (e) {} }
};

// ===================== form helpers =====================
function section(title, ...kids) { return h('div', { class: 'sec' }, title ? h('h3', null, title) : null, ...kids); }
function slider(label, val, min, max, step, show, onInput, onChange) {
  const out = h('output', null, show(val));
  const r = h('input', { type: 'range', min, max, step, value: val });
  r.addEventListener('input', () => { const v = parseFloat(r.value); out.textContent = show(v); onInput(v); });
  if (onChange) r.addEventListener('change', () => onChange(parseFloat(r.value)));
  return h('label', { class: 'slider' }, h('span', { class: 'sl-top' }, h('span', null, label), out), r);
}
function chips(options, current, onPick, cls) {
  const wrap = h('div', { class: 'chips ' + (cls || '') });
  const render = cur => {
    wrap.innerHTML = '';
    for (const o of options) {
      const [val, label, disabled, extra] = Array.isArray(o) ? o : [o, o];
      const b = h('button', { class: 'chip' + (val === cur ? ' on' : ''), disabled: !!disabled, onclick: () => { onPick(val); render(val); } }, extra || null, label);
      wrap.append(b);
    }
  };
  render(current); wrap.rerender = render; return wrap;
}
function toggle(label, on, onChange) {
  const i = h('input', { type: 'checkbox', checked: !!on });
  i.addEventListener('change', () => onChange(i.checked));
  return h('label', { class: 'toggle' }, h('span', null, label), i, h('i'));
}
function btn(label, ic, onClick, cls) {
  return h('button', { class: 'btn ' + (cls || ''), onclick: onClick }, ic ? h('span', { html: icon(ic, 18) }) : null, label);
}
function selectEl(options, val, onChange) {
  const s = h('select');
  for (const [v, l] of options) s.append(h('option', { value: v, selected: v === val }, l));
  s.addEventListener('change', () => onChange(s.value));
  return s;
}
const pct = v => Math.round(v * 100) + '%';
const secs = v => v.toFixed(1) + ' s';

// ===================== sheet system =====================
let sheetCtx = null;
function openSheet(name, opts) {
  const def = SHEETS[name]; if (!def) return;
  if (def.needSel && !findItem(S.sel)) return toast('Select a clip first');
  if (def.pause !== false) pause();
  S.sheetSnap = false;
  const sh = $('#sheet'), body = $('#sheetBody');
  $('#sheetTitle').textContent = typeof def.title === 'function' ? def.title(opts) : def.title;
  body.innerHTML = ''; body.scrollTop = 0;
  def.build(body, opts || {});
  sh.classList.toggle('tall', !!def.tall);
  const tb = document.querySelector('.transport').getBoundingClientRect().bottom;
  sh.style.setProperty('--top', def.tall ? '' : tb + 'px');
  sh.classList.add('open'); document.body.classList.add('sheet-open');
  sheetCtx = { name, opts };
}
function closeSheet() {
  if (!sheetCtx) return;
  $('#sheet').classList.remove('open'); document.body.classList.remove('sheet-open');
  sheetCtx = null; S.sheetSnap = false;
  renderTimeline(); renderDock(); requestDraw(); updateTC(); updateEmpty();
}
function sel() { return findItem(S.sel); }
function liveRefresh() { requestDraw(); }

const defaultY = st => (st && st.y) || (['16:9', '21:9', '4:3'].includes(S.p.ratio) ? 0.84 : 0.74);

const SHEETS = {
  addAudio: {
    title: 'Add audio',
    build(b) {
      b.append(section(null,
        h('div', { class: 'big-actions' },
          bigAction('music', 'Music or sound', 'MP3, WAV, M4A, OGG, FLAC', () => { closeSheet(); $('#inAudio').click(); }),
          bigAction('detach', 'Sound from a video', 'Uses the audio of any video file', () => { closeSheet(); $('#inAudioVid').click(); }),
          bigAction('voice', 'AI voice', 'Type a script, ElevenLabs reads it', () => openSheet('tts'))
        ),
        h('p', { class: 'hint' }, 'New audio is placed at the playhead on the first free track.')));
    }
  },
  addText: {
    title: 'Add text',
    build(b) {
      let dur = 3;
      const ta = h('textarea', { rows: 3, placeholder: 'Type your text' });
      b.append(section(null, ta, slider('Duration', dur, 0.5, 15, 0.5, secs, v => dur = v),
        h('p', { class: 'hint' }, 'Uses the style "' + (STYLE_BY_ID[S.p.defStyle] || {}).name + '". Change it from Styles.'),
        btn('Add text', 'plus', () => {
          const text = ta.value.trim(); if (!text) return toast('Type some text first');
          edit(() => {
            const st = STYLE_BY_ID[S.p.defStyle];
            const tx = { id: uid(), start: S.t, end: S.t + dur, text, styleId: S.p.defStyle, x: 0.5, y: defaultY(st), scale: 1, words: null, ov: {} };
            S.p.texts.push(tx); S.sel = { type: 'text', id: tx.id };
          });
          closeSheet();
        }, 'primary')));
      setTimeout(() => ta.focus(), 250);
    }
  },
  editText: {
    title: 'Edit text', needSel: true,
    build(b) {
      const it = sel();
      const ta = h('textarea', { rows: 3 }); ta.value = it.text;
      ta.addEventListener('input', () => {
        touchEdit(); const n0 = (it.text.trim().split(/\s+/)).length; it.text = ta.value;
        if (it.words && ta.value.trim().split(/\s+/).length !== n0) it.words = null;
        requestDraw();
      });
      b.append(section(null, ta,
        slider('Duration', it.end - it.start, 0.3, 30, 0.1, secs, v => { touchEdit(); it.end = it.start + v; requestDraw(); }),
        h('p', { class: 'hint' }, 'Drag the text on the preview to move it. Pinch with two fingers to resize.')));
    }
  },
  style: {
    title: o => (o && o.all ? 'Subtitle styles' : 'Text style'), tall: true,
    build(b, o) {
      const single = !o.all && S.sel && S.sel.type === 'text' ? sel() : null;
      let applyAll = !single;
      const targets = () => (applyAll ? S.p.texts : [single]);
      const curId = single ? single.styleId : S.p.defStyle;
      const filters = [['all', 'All'], ['hl', 'Word highlight'], ['box', 'Boxed'], ['outline', 'Outline'], ['glow', 'Shadow and glow']];
      const match = (s, f) => f === 'all' || (f === 'hl' && (s.hl || s.hlBg || s.hlFillWord)) || (f === 'box' && s.bg) || (f === 'outline' && s.stroke && !s.bg) || (f === 'glow' && (s.glow || (s.shadow && !s.stroke)));
      const grid = h('div', { class: 'style-grid' });
      let filter = 'all', current = curId;
      const pick = id => {
        touchEdit(); current = id; S.p.defStyle = id;
        for (const t of targets()) { t.styleId = id; const st = STYLE_BY_ID[id]; if (st.y && t.y > 0.6) t.y = st.y; }
        grid.querySelectorAll('.st').forEach(e => e.classList.toggle('on', e.dataset.id === id));
        requestDraw();
      };
      const fill = () => {
        grid.innerHTML = '';
        Presets.SUB_STYLES.filter(s => match(s, filter)).forEach(s => {
          const c = h('canvas', { width: 220, height: 124 });
          const cell = h('button', { class: 'st' + (s.id === current ? ' on' : ''), 'data-id': s.id, onclick: () => pick(s.id) }, c, h('span', null, s.name));
          grid.append(cell); drawStyleThumb(c, s);
        });
      };
      b.append(chips(filters, filter, v => { filter = v; fill(); }, 'scroll'));
      if (single) b.append(toggle('Apply to all subtitles', applyAll, v => { applyAll = v; if (v) pick(current); }));
      b.append(grid); fill();
      const first = targets()[0] || {};
      const ov = first.ov || {};
      const color = (label, key, def) => {
        const i = h('input', { type: 'color', value: ov[key] || def });
        i.addEventListener('input', () => { touchEdit(); for (const t of targets()) { t.ov = t.ov || {}; t.ov[key] = i.value; } requestDraw(); });
        return h('label', { class: 'color' }, i, h('span', null, label));
      };
      const st0 = STYLE_BY_ID[current] || {};
      b.append(section('Fine-tune',
        slider('Size', first.scale || 1, 0.4, 2.5, 0.05, pct, v => { touchEdit(); for (const t of targets()) t.scale = v; requestDraw(); }),
        h('div', { class: 'colors' },
          color('Text', 'fill', st0.fill && st0.fill.startsWith('#') ? st0.fill : '#ffffff'),
          color('Outline', 'stroke', st0.stroke || '#000000'),
          color('Highlight', 'hl', st0.hl || st0.accent || '#FFD60A')),
        btn('Reset colors', 'refresh', () => { touchEdit(); for (const t of targets()) t.ov = {}; requestDraw(); toast('Colors reset'); }, 'ghost-btn')));
    }
  },
  position: {
    title: 'Position', needSel: true,
    build(b) {
      const it = sel(); let all = false;
      const apply = (x, y) => { touchEdit(); for (const t of (all ? S.p.texts : [it])) { if (x != null) t.x = x; if (y != null) t.y = y; } requestDraw(); };
      const ys = h('div');
      const build = () => {
        ys.innerHTML = '';
        ys.append(slider('Horizontal', it.x, 0.05, 0.95, 0.01, pct, v => apply(v, null)), slider('Vertical', it.y, 0.04, 0.96, 0.01, pct, v => apply(null, v)));
      };
      b.append(section(null,
        h('div', { class: 'row-btns' },
          btn('Top', null, () => { apply(0.5, 0.16); build(); }), btn('Middle', null, () => { apply(0.5, 0.5); build(); }),
          btn('Lower', null, () => { apply(0.5, 0.72); build(); }), btn('Bottom', null, () => { apply(0.5, 0.86); build(); })),
        ys, toggle('Apply to all subtitles', all, v => { all = v; if (v) apply(it.x, it.y); }),
        h('p', { class: 'hint' }, 'You can also drag any subtitle directly on the preview.')));
      build();
    }
  },
  volume: {
    title: 'Volume', needSel: true, pause: false,
    build(b) {
      const it = sel();
      const s = section(null,
        slider('Volume', it.volume, 0, 2, 0.01, pct, v => { touchEdit(); it.volume = v; }, () => refreshPlayback()),
        slider('Fade in', it.fadeIn, 0, 5, 0.1, secs, v => { touchEdit(); it.fadeIn = v; }, () => refreshPlayback()),
        slider('Fade out', it.fadeOut, 0, 5, 0.1, secs, v => { touchEdit(); it.fadeOut = v; }, () => refreshPlayback()));
      if (S.sel.type === 'main') s.append(toggle('Mute this clip', it.muted, v => { touchEdit(); it.muted = v; refreshPlayback(); }));
      b.append(s);
    }
  },
  fx: {
    title: 'Voice and audio effects', needSel: true, pause: false, tall: true,
    build(b) {
      const it = sel();
      const cats = [...new Set(AudioFX.FX.map(f => f.cat))];
      const grid = h('div');
      const render = () => {
        grid.innerHTML = '';
        for (const c of cats) {
          const g = h('div', { class: 'fx-grid' });
          AudioFX.FX.filter(f => f.cat === c).forEach(f => g.append(h('button', { class: 'fx' + (it.fx === f.id ? ' on' : ''), onclick: () => {
            touchEdit(); it.fx = f.id; render(); previewSel(); } }, h('span', { html: icon(fxIcon(f), 20) }), h('b', null, f.name))));
          grid.append(section(c, g));
        }
      };
      render();
      b.append(h('p', { class: 'hint' }, 'Tap an effect to hear it on this clip.'), grid,
        btn('Apply to all audio clips', 'check', () => { touchEdit(); for (const c of [...S.p.main.filter(x => x.kind === 'video'), ...S.p.audio]) c.fx = it.fx; refreshPlayback(); toast('Applied to every clip'); }, 'ghost-btn'));
    }
  },
  eq: {
    title: 'Equalizer', needSel: true, pause: false,
    build(b) {
      const it = sel(); if (!it.eq) it.eq = zeros();
      const bands = h('div', { class: 'eq' });
      const draw = () => {
        bands.innerHTML = '';
        Presets.EQ_BANDS.forEach((f, i) => {
          const out = h('output', null, (it.eq[i] > 0 ? '+' : '') + it.eq[i]);
          const r = h('input', { type: 'range', min: -12, max: 12, step: 1, value: it.eq[i], class: 'vert' });
          r.addEventListener('input', () => { touchEdit(); it.eq[i] = +r.value; out.textContent = (it.eq[i] > 0 ? '+' : '') + it.eq[i]; });
          r.addEventListener('change', () => refreshPlayback());
          bands.append(h('div', { class: 'band' }, out, r, h('span', null, f >= 1000 ? f / 1000 + 'k' : f)));
        });
      };
      draw();
      b.append(chips(Presets.EQ_PRESETS.map(p => [p.name, p.name]), null, name => {
        touchEdit(); it.eq = [...Presets.EQ_PRESETS.find(p => p.name === name).g]; draw(); refreshPlayback(); if (!S.playing) previewSel();
      }, 'scroll'), bands, h('p', { class: 'hint' }, 'Gain in dB. Changes apply when you lift your finger.'));
    }
  },
  look: {
    title: 'Filters', needSel: true,
    build(b) {
      const it = sel(), m = media(it);
      const g = h('div', { class: 'look-grid' });
      const render = () => {
        g.innerHTML = '';
        Presets.LOOKS.forEach(l => g.append(h('button', { class: 'look' + (it.look === l.id ? ' on' : ''), onclick: () => { touchEdit(); it.look = l.id; render(); requestDraw(); } },
          h('img', { src: m.thumb, style: 'filter:' + l.f, alt: '' }), h('span', null, l.name))));
      };
      render();
      b.append(g, btn('Apply to all clips', 'check', () => { touchEdit(); S.p.main.forEach(c => c.look = it.look); requestDraw(); toast('Applied to every clip'); }, 'ghost-btn'));
    }
  },
  trans: {
    title: 'Fades', needSel: true,
    build(b) {
      const it = sel();
      b.append(section(null,
        toggle('Fade in from black', it.vIn, v => { touchEdit(); it.vIn = v; requestDraw(); }),
        toggle('Fade out to black', it.vOut, v => { touchEdit(); it.vOut = v; requestDraw(); }),
        h('p', { class: 'hint' }, 'Audio fades are under Volume.')));
    }
  },
  duration: {
    title: 'Photo duration', needSel: true,
    build(b) { const it = sel(); b.append(section(null, slider('Duration', it.dur, 0.5, 30, 0.1, secs, v => { touchEdit(); it.dur = v; }))); }
  },
  motion: {
    title: 'Photo motion', needSel: true,
    build(b) {
      const it = sel();
      b.append(section(null, chips([['none', 'Still'], ['zoomIn', 'Zoom in'], ['zoomOut', 'Zoom out'], ['panL', 'Pan left'], ['panR', 'Pan right'], ['panU', 'Pan up']], it.motion, v => { touchEdit(); it.motion = v; requestDraw(); })));
    }
  },
  canvas: {
    title: 'Format',
    build(b) {
      const ratioIcon = r => { const [a, c] = RATIOS[r]; const s = 18 / Math.max(a, c); return h('i', { class: 'ratio-ic', style: `width:${a * s}px;height:${c * s}px` }); };
      b.append(section('Aspect ratio', chips(Object.keys(RATIOS).map(r => [r, r, false, ratioIcon(r)]), S.p.ratio, v => { touchEdit(); S.p.ratio = v; layoutStage(); })));
      b.append(section('Fit', chips([['contain', 'Fit whole frame'], ['cover', 'Fill and crop']], S.p.fit, v => { touchEdit(); S.p.fit = v; requestDraw(); })));
      const sw = [['blur', 'Blur'], ...Object.keys(BG_COLORS).map(k => [k, k[0].toUpperCase() + k.slice(1)])];
      b.append(section('Background', chips(sw.map(([k, l]) => [k, l, false, h('i', { class: 'swatch' + (k === 'blur' ? ' blur' : ''), style: k === 'blur' ? '' : 'background:' + BG_COLORS[k] })]), S.p.bg, v => { touchEdit(); S.p.bg = v; requestDraw(); })));
    }
  },
  tts: { title: 'AI voice', tall: true, build: buildTTS },
  captions: { title: 'Captions', tall: true, build: buildCaptions },
  export: { title: 'Export', tall: true, build: buildExport },
  saved: { title: 'Export finished', build: buildSaved }
};

function bigAction(ic, title, sub, fn) {
  return h('button', { class: 'big', onclick: fn }, h('span', { class: 'bi', html: icon(ic, 24) }), h('span', null, h('b', null, title), h('small', null, sub)));
}
function fxIcon(f) { return { Voice: 'mic', Character: 'fx', Space: 'trans', Music: 'music' }[f.cat] || 'fx'; }
function previewSel() {
  const r = S.sel.type === 'main' ? mainLayout().find(x => x.clip.id === S.sel.id) : null;
  const it = sel(); if (!it) return;
  const st = r ? r.start : it.start, en = r ? r.start + r.dur : it.start + it.out - it.in;
  if (S.playing) { refreshPlayback(); return; }
  if (S.t < st || S.t >= en - 0.2) seek(st);
  play();
}
function drawStyleThumb(c, s) {
  const g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, c.width, c.height); gr.addColorStop(0, '#2B3346'); gr.addColorStop(1, '#151A24');
  g.fillStyle = gr; g.fillRect(0, 0, c.width, c.height);
  const tx = { id: 'pv', text: 'Make it pop', start: -10, end: 3, x: 0.5, y: 0.5, scale: 2.9 * 0.072 / s.size * (s.single ? 1.4 : 1), styleId: s.id, ov: {}, words: [{ s: 0, e: 1 }, { s: 1, e: 2 }, { s: 2, e: 3 }] };
  drawSubtitle(g, c.width, c.height, tx, 1.5, false);
}

// ===================== ElevenLabs =====================
const EL = 'https://api.elevenlabs.io';
const getKey = () => store.get('elkey', '');
async function elReq(path, init) {
  const key = getKey(); if (!key) throw new Error('Add your ElevenLabs API key first.');
  init = init || {};
  let r;
  try { r = await fetch(EL + path, Object.assign({}, init, { headers: Object.assign({ 'xi-api-key': key }, init.headers || {}) })); }
  catch (e) { throw new Error('Could not reach ElevenLabs. Check your internet connection.'); }
  if (!r.ok) {
    let msg = r.statusText;
    try { const j = await r.json(); msg = (j.detail && (j.detail.message || j.detail.status || (typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail)))) || JSON.stringify(j); } catch (e) {}
    if (r.status === 401) msg = 'The API key was rejected. ' + msg;
    throw new Error('ElevenLabs (' + r.status + '): ' + msg);
  }
  return r;
}
async function fetchVoices() {
  let list = [];
  try {
    const j = await (await elReq('/v2/voices?page_size=100')).json(); list = j.voices || [];
  } catch (e) {
    const j = await (await elReq('/v1/voices')).json(); list = j.voices || [];
  }
  const v = list.map(x => ({ id: x.voice_id, name: x.name, info: [x.labels && x.labels.gender, x.labels && x.labels.accent, x.category].filter(Boolean).join(', ') }));
  store.set('voices', v); return v;
}
const DEFAULT_VOICES = [
  { id: '21m00Tcm4TlvDq8ikWAM', name: 'Rachel', info: 'female, american' }, { id: 'pNInz6obpgDQGcFmaJgB', name: 'Adam', info: 'male, american' },
  { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Sarah', info: 'female, american' }, { id: 'TxGEqnHWrfWFTfGW9XjX', name: 'Josh', info: 'male, american' },
  { id: 'ErXwobaYiN019PkySvjV', name: 'Antoni', info: 'male, american' }, { id: 'MF3mGyEYCl7XYWbV9V6O', name: 'Elli', info: 'female, american' }
];
const TTS_MODELS = [['eleven_multilingual_v2', 'Multilingual v2 (best quality)'], ['eleven_v3', 'Eleven v3 (most expressive)'], ['eleven_turbo_v2_5', 'Turbo v2.5 (fast)'], ['eleven_flash_v2_5', 'Flash v2.5 (fastest, cheapest)']];

function keyBox(onSaved) {
  const has = !!getKey();
  const inp = h('input', { type: 'password', placeholder: 'Paste your ElevenLabs API key', autocomplete: 'off', value: getKey() });
  const status = h('p', { class: 'hint' }, has ? 'Key saved on this phone.' : 'Find it at elevenlabs.io, under Developers, then API keys.');
  return section('ElevenLabs API key',
    h('div', { class: 'inline' }, inp, btn('Save', 'check', async () => {
      store.set('elkey', inp.value.trim()); if (!inp.value.trim()) { status.textContent = 'Key removed.'; return; }
      status.textContent = 'Checking key…';
      try { const v = await fetchVoices(); status.textContent = `Key works. ${v.length} voices loaded.`; onSaved && onSaved(v); }
      catch (e) { status.textContent = e.message; }
    })), status);
}

function buildTTS(b) {
  const cfg = Object.assign({ voice: DEFAULT_VOICES[0].id, model: 'eleven_multilingual_v2', stability: 0.5, similarity: 0.75, style: 0, speed: 1, subs: true, words: 4, place: 'playhead', text: '' }, store.get('tts', {}));
  const save = () => store.set('tts', cfg);
  let voices = store.get('voices', null) || DEFAULT_VOICES;
  const vWrap = h('div', { class: 'inline' });
  const drawVoices = () => {
    vWrap.innerHTML = '';
    if (!voices.find(v => v.id === cfg.voice)) cfg.voice = voices[0] && voices[0].id;
    vWrap.append(selectEl(voices.map(v => [v.id, v.name + (v.info ? '  (' + v.info + ')' : '')]), cfg.voice, v => { cfg.voice = v; save(); }),
      h('button', { class: 'icon-btn', title: 'Reload voices', html: icon('refresh', 20), onclick: async () => {
        try { toast('Loading voices…'); voices = await fetchVoices(); drawVoices(); toast(voices.length + ' voices loaded'); } catch (e) { toast(e.message, 'err'); } } }));
  };
  drawVoices();
  const ta = h('textarea', { rows: 6, placeholder: 'Write what the voice should say. Long scripts are split automatically.' }); ta.value = cfg.text;
  const count = h('span', { class: 'count' }, ta.value.length + ' characters');
  ta.addEventListener('input', () => { cfg.text = ta.value; count.textContent = ta.value.length + ' characters'; save(); });
  const go = btn('Generate voice', 'voice', async () => {
    const text = ta.value.trim(); if (!text) return toast('Write a script first');
    go.disabled = true; go.classList.add('busy');
    try { await generateVoice(text, cfg); closeSheet(); }
    catch (e) { toast(e.message, 'err', 7000); }
    finally { go.disabled = false; go.classList.remove('busy'); }
  }, 'primary');
  b.append(
    keyBox(v => { voices = v; drawVoices(); }),
    section('Script', ta, count),
    section('Voice', vWrap, selectEl(TTS_MODELS, cfg.model, v => { cfg.model = v; save(); }),
      slider('Stability', cfg.stability, 0, 1, 0.05, pct, v => { cfg.stability = v; save(); }),
      slider('Similarity', cfg.similarity, 0, 1, 0.05, pct, v => { cfg.similarity = v; save(); }),
      slider('Style exaggeration', cfg.style, 0, 1, 0.05, pct, v => { cfg.style = v; save(); }),
      slider('Speed', cfg.speed, 0.7, 1.2, 0.01, v => v.toFixed(2) + '×', v => { cfg.speed = v; save(); })),
    section('Subtitles',
      toggle('Turn the script into synced subtitles', cfg.subs, v => { cfg.subs = v; save(); }),
      slider('Words per subtitle', cfg.words, 1, 10, 1, v => String(v), v => { cfg.words = v; save(); }),
      h('p', { class: 'hint' }, 'Style: ' + (STYLE_BY_ID[S.p.defStyle] || {}).name + '. Subtitles move with the voice clip when you drag it.')),
    section('Place on timeline', chips([['playhead', 'At playhead'], ['start', 'At the start'], ['end', 'After the last audio']], cfg.place, v => { cfg.place = v; save(); })),
    go);
}

function splitScript(text, max) {
  const parts = [], sentences = text.replace(/\s+/g, ' ').match(/[^.!?…]+[.!?…]*\s*/g) || [text];
  let cur = '';
  for (const s of sentences) {
    if ((cur + s).length > max && cur) { parts.push(cur.trim()); cur = ''; }
    if (s.length > max) { for (let i = 0; i < s.length; i += max) parts.push(s.slice(i, i + max).trim()); }
    else cur += s;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}
function wordsFromAlignment(al) {
  if (!al || !al.characters) return [];
  const ch = al.characters, s = al.character_start_times_seconds, e = al.character_end_times_seconds;
  const out = []; let cur = null;
  for (let i = 0; i < ch.length; i++) {
    if (/\s/.test(ch[i])) { if (cur) { out.push(cur); cur = null; } continue; }
    if (!cur) cur = { w: '', s: s[i], e: e[i] };
    cur.w += ch[i]; cur.e = e[i];
  }
  if (cur) out.push(cur);
  return out.filter(w => !/^\[[^\]]*\]$/.test(w.w));
}
function makeCaptions(words, offset, o) {
  const out = []; let cur = [];
  const maxWords = o.maxWords || 4, maxChars = o.maxChars || 34;
  const flush = () => { if (cur.length) out.push(cur); cur = []; };
  words.forEach((w, i) => {
    const prev = cur[cur.length - 1];
    const chars = cur.reduce((a, x) => a + x.w.length + 1, 0);
    const endsSentence = /[.!?…]$/.test(w.w), nextGap = words[i + 1] ? words[i + 1].s - w.e : 9;
    const full = cur.length >= maxWords && !(endsSentence && cur.length <= maxWords && chars + w.w.length <= maxChars + 8 && nextGap > 0.05);
    if (cur.length && (full || chars + w.w.length > maxChars + (endsSentence ? 8 : 0) || (prev && w.s - prev.e > 0.7) || (prev && /[.!?…]$/.test(prev.w)) || (prev && /[,;:]$/.test(prev.w) && cur.length >= 2))) flush();
    cur.push(w);
  });
  flush();
  const st = STYLE_BY_ID[o.styleId];
  return out.map((g, i) => {
    const next = out[i + 1];
    const start = offset + g[0].s;
    let end = offset + g[g.length - 1].e + 0.25;
    if (next) end = Math.min(end, offset + next[0].s);
    end = Math.max(end, start + 0.3);
    return { id: uid(), start, end, text: g.map(w => w.w).join(' '), styleId: o.styleId, x: 0.5, y: defaultY(st), scale: 1,
      words: g.map(w => ({ s: offset + w.s, e: offset + w.e })), ov: {}, auto: !!o.auto, linkId: o.linkId || null };
  });
}
function b64ToBytes(b64) { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }

async function generateVoice(text, cfg) {
  const parts = splitScript(text, cfg.model === 'eleven_v3' ? 2800 : 4500);
  let at = cfg.place === 'start' ? 0 : cfg.place === 'end' ? S.p.audio.reduce((a, x) => Math.max(a, x.start + x.out - x.in), 0) : S.t;
  const made = [];
  for (let i = 0; i < parts.length; i++) {
    toast(parts.length > 1 ? `Generating voice, part ${i + 1} of ${parts.length}…` : 'Generating voice…', '', 120000);
    const r = await elReq(`/v1/text-to-speech/${encodeURIComponent(cfg.voice)}/with-timestamps?output_format=mp3_44100_128`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: parts[i], model_id: cfg.model, voice_settings: { stability: cfg.stability, similarity_boost: cfg.similarity, style: cfg.style, use_speaker_boost: true, speed: cfg.speed } })
    });
    const j = await r.json();
    if (!j.audio_base64) throw new Error('ElevenLabs returned no audio.');
    const file = new File([b64ToBytes(j.audio_base64)], 'AI voice ' + (made.length + 1) + '.mp3', { type: 'audio/mpeg' });
    const m = await loadMedia(file, false);
    made.push({ m, at, words: wordsFromAlignment(j.alignment || j.normalized_alignment), text: parts[i] });
    at += m.duration;
  }
  edit(() => {
    for (const x of made) {
      const a = mkAudio(x.m, x.at, { tts: true, label: x.text.slice(0, 40) });
      S.p.audio.push(a);
      if (cfg.subs && x.words.length) S.p.texts.push(...makeCaptions(x.words, x.at, { maxWords: cfg.words, styleId: S.p.defStyle, linkId: a.id }));
    }
    S.sel = null;
  });
  toast('Voice added to the timeline');
}

// ---------- auto captions (speech-to-text) ----------
const LANGS = [['', 'Detect automatically'], ['en', 'English'], ['fr', 'French'], ['es', 'Spanish'], ['de', 'German'], ['it', 'Italian'], ['pt', 'Portuguese'], ['nl', 'Dutch'], ['ar', 'Arabic'], ['tr', 'Turkish'], ['ru', 'Russian'], ['pl', 'Polish'], ['hi', 'Hindi'], ['ja', 'Japanese'], ['ko', 'Korean'], ['zh', 'Chinese']];
function buildCaptions(b) {
  const cfg = Object.assign({ source: 'all', lang: '', words: 4, replace: true, model: 'scribe_v2' }, store.get('cap', {}));
  const save = () => store.set('cap', cfg);
  const hasClip = S.sel && (S.sel.type === 'audio' || (S.sel.type === 'main' && sel() && sel().kind === 'video'));
  if (!hasClip) cfg.source = 'all';
  const go = btn('Generate captions', 'cc', async () => {
    go.disabled = true; go.classList.add('busy');
    try { await autoCaptions(cfg); closeSheet(); } catch (e) { toast(e.message, 'err', 7000); }
    finally { go.disabled = false; go.classList.remove('busy'); }
  }, 'primary');
  b.append(
    section('Auto captions',
      h('p', { class: 'hint' }, 'Listens to your audio with ElevenLabs Speech-to-Text and creates word-timed subtitles.'),
      chips([['all', 'Whole project'], ['clip', 'Selected clip only', !hasClip]], cfg.source, v => { cfg.source = v; save(); }),
      selectEl(LANGS, cfg.lang, v => { cfg.lang = v; save(); }),
      selectEl([['scribe_v2', 'Scribe v2 (recommended)'], ['scribe_v1', 'Scribe v1']], cfg.model, v => { cfg.model = v; save(); }),
      slider('Words per caption', cfg.words, 1, 10, 1, v => String(v), v => { cfg.words = v; save(); }),
      toggle('Replace earlier auto captions', cfg.replace, v => { cfg.replace = v; save(); }),
      go),
    keyBox(),
    section('Subtitle files',
      h('div', { class: 'row-btns' },
        btn('Import SRT or VTT', 'file', () => $('#inSubs').click()),
        btn('Style all captions', 'style', () => openSheet('style', { all: true }))),
      btn('Delete all subtitles', 'trash', () => { if (!S.p.texts.length) return; edit(() => { S.p.texts = []; }); toast('Subtitles deleted'); }, 'ghost-btn danger')));
}
async function autoCaptions(cfg) {
  let segs = audioSegments(), from = 0, to = totalDur();
  if (cfg.source === 'clip' && S.sel) {
    segs = segs.filter(s => s.clip.id === S.sel.id);
    if (segs.length) { from = segs[0].tlStart; to = from + segs[0].dur; }
  }
  if (!segs.length) throw new Error('There is no audio to transcribe. Add a video with sound or an audio clip.');
  if (!getKey()) throw new Error('Add your ElevenLabs API key below first.');
  toast('Preparing audio…', '', 120000);
  const buf = await AudioFX.mixdown(segs, from, to, 16000, 1);
  const mp3 = await AudioFX.toMp3(buf, 64);
  toast('Transcribing… this can take a moment', '', 300000);
  const fd = new FormData();
  fd.append('file', mp3, 'audio.mp3'); fd.append('model_id', cfg.model || 'scribe_v2');
  fd.append('timestamps_granularity', 'word'); fd.append('tag_audio_events', 'false');
  if (cfg.lang) fd.append('language_code', cfg.lang);
  const j = await (await elReq('/v1/speech-to-text', { method: 'POST', body: fd })).json();
  const words = (j.words || []).filter(w => w.type === 'word' && w.text && w.text.trim()).map(w => ({ w: w.text.trim(), s: w.start, e: w.end }));
  if (!words.length) throw new Error('No speech was found in the audio.');
  edit(() => {
    if (cfg.replace) S.p.texts = S.p.texts.filter(x => !x.auto);
    S.p.texts.push(...makeCaptions(words, from, { maxWords: cfg.words, styleId: S.p.defStyle, auto: true }));
  });
  toast(`Created captions from ${words.length} words`);
}

// ---------- subtitle files ----------
function parseTime(s) {
  const m = s.trim().replace(',', '.').split(':').map(Number);
  return m.length === 3 ? m[0] * 3600 + m[1] * 60 + m[2] : m.length === 2 ? m[0] * 60 + m[1] : m[0];
}
function parseSubs(text) {
  const out = [];
  for (const block of text.replace(/\r/g, '').split(/\n\s*\n/)) {
    const lines = block.split('\n'); const i = lines.findIndex(l => l.includes('-->'));
    if (i < 0) continue;
    const [a, b] = lines[i].split('-->');
    const body = lines.slice(i + 1).join(' ').replace(/<[^>]+>/g, '').replace(/\{[^}]+\}/g, '').trim();
    if (body) out.push({ start: parseTime(a), end: parseTime(b.trim().split(/\s/)[0]), text: body });
  }
  return out;
}
const pad = (n, l) => String(Math.floor(n)).padStart(l || 2, '0');
function tcode(t, sep) { return pad(t / 3600) + ':' + pad((t % 3600) / 60) + ':' + pad(t % 60) + sep + pad((t * 1000) % 1000, 3); }
function subsFile(kind) {
  const T = [...S.p.texts].sort((a, b) => a.start - b.start);
  if (kind === 'srt') return T.map((x, i) => `${i + 1}\n${tcode(x.start, ',')} --> ${tcode(x.end, ',')}\n${x.text}\n`).join('\n');
  if (kind === 'vtt') return 'WEBVTT\n\n' + T.map(x => `${tcode(x.start, '.')} --> ${tcode(x.end, '.')}\n${x.text}\n`).join('\n');
  return T.map(x => x.text).join(' ').replace(/\s+/g, ' ').trim() + '\n';
}

// ===================== export =====================
const VFORMATS = [
  { id: 'mp4', label: 'MP4', sub: 'H.264 + AAC, plays everywhere', ext: 'mp4', mimes: ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.4d0028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01F,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4;codecs=avc3,mp4a.40.2', 'video/mp4'] },
  { id: 'mp4hevc', label: 'MP4 HEVC', sub: 'H.265, smaller files', ext: 'mp4', mimes: ['video/mp4;codecs=hvc1.1.6.L120.90,mp4a.40.2', 'video/mp4;codecs=hev1.1.6.L120.90,mp4a.40.2', 'video/mp4;codecs=hvc1,mp4a.40.2'] },
  { id: 'mp4av1', label: 'MP4 AV1', sub: 'Newest codec', ext: 'mp4', mimes: ['video/mp4;codecs=av01.0.08M.08,mp4a.40.2', 'video/mp4;codecs=av01,mp4a.40.2', 'video/mp4;codecs=av01,opus'] },
  { id: 'webm9', label: 'WebM VP9', sub: 'VP9 + Opus, for the web', ext: 'webm', mimes: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp09.00.10.08,opus'] },
  { id: 'webm8', label: 'WebM VP8', sub: 'VP8 + Opus, widest browser support', ext: 'webm', mimes: ['video/webm;codecs=vp8,opus', 'video/webm'] },
  { id: 'webmav1', label: 'WebM AV1', sub: 'AV1 + Opus', ext: 'webm', mimes: ['video/webm;codecs=av01,opus', 'video/webm;codecs=av1,opus'] },
  { id: 'webmh264', label: 'WebM H.264', sub: 'H.264 + Opus', ext: 'webm', mimes: ['video/webm;codecs=h264,opus', 'video/webm;codecs=avc1,opus'] },
  { id: 'mkv', label: 'MKV', sub: 'Matroska, H.264 + Opus', ext: 'mkv', mimes: ['video/x-matroska;codecs=avc1,opus', 'video/x-matroska;codecs=h264,opus', 'video/x-matroska;codecs=avc1,pcm'] },
  { id: 'mkv9', label: 'MKV VP9', sub: 'Matroska, VP9 + Opus', ext: 'mkv', mimes: ['video/x-matroska;codecs=vp9,opus'] }
];
const AFORMATS = [
  { id: 'mp3', label: 'MP3', sub: 'Universal audio', ext: 'mp3', offline: true },
  { id: 'wav', label: 'WAV', sub: 'Lossless, 16-bit', ext: 'wav', offline: true },
  { id: 'm4a', label: 'M4A', sub: 'AAC, recorded in real time', ext: 'm4a', mimes: ['audio/mp4;codecs=mp4a.40.2', 'audio/mp4'] },
  { id: 'opus', label: 'Opus', sub: 'WebM audio, recorded in real time', ext: 'webm', mimes: ['audio/webm;codecs=opus', 'audio/webm'] },
  { id: 'ogg', label: 'OGG', sub: 'Ogg Opus, recorded in real time', ext: 'ogg', mimes: ['audio/ogg;codecs=opus', 'audio/ogg'] }
];
const mimeFor = f => (f.offline ? 'ok' : (window.MediaRecorder && f.mimes.find(m => { try { return MediaRecorder.isTypeSupported(m); } catch (e) { return false; } })) || null);
const QUALITY = { low: 0.05, standard: 0.09, high: 0.15, max: 0.24 };

function exportDims(res) {
  const [a, b] = RATIOS[S.p.ratio];
  let W, H;
  if (a >= b) { H = res; W = Math.round(res * a / b); } else { W = res; H = Math.round(res * b / a); }
  return [W - (W % 2), H - (H % 2)];
}
function defaultName() { const d = new Date(); return 'ReelForge_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()); }

function buildExport(b) {
  const cfg = Object.assign({ tab: 'video', vf: 'mp4', res: 1080, fps: 30, q: 'high', subs: true, af: 'mp3', kbps: 192, sr: 44100, sf: 'srt' }, store.get('export', {}));
  const save = () => store.set('export', cfg);
  const body = h('div');
  const name = h('input', { type: 'text', value: defaultName() });
  const info = h('p', { class: 'hint' });
  const go = btn('Export', 'download', () => run(), 'primary');
  const render = () => {
    body.innerHTML = '';
    if (cfg.tab === 'video') {
      const opts = VFORMATS.map(f => { const m = mimeFor(f); return [f.id, f.label, !m, null, f.sub]; });
      if (!mimeFor(VFORMATS.find(f => f.id === cfg.vf))) { const first = VFORMATS.find(f => mimeFor(f)); cfg.vf = first ? first.id : cfg.vf; }
      body.append(
        section('Format', formatList(opts, cfg.vf, v => { cfg.vf = v; save(); upd(); })),
        section('Resolution', chips([[480, '480p'], [720, '720p'], [1080, '1080p'], [1440, '2K'], [2160, '4K']], cfg.res, v => { cfg.res = v; save(); upd(); })),
        section('Frame rate', chips([[24, '24'], [25, '25'], [30, '30'], [50, '50'], [60, '60']], cfg.fps, v => { cfg.fps = v; save(); upd(); })),
        section('Quality', chips([['low', 'Small file'], ['standard', 'Standard'], ['high', 'High'], ['max', 'Maximum']], cfg.q, v => { cfg.q = v; save(); upd(); })),
        section(null, toggle('Burn subtitles into the video', cfg.subs, v => { cfg.subs = v; save(); })));
    } else if (cfg.tab === 'audio') {
      body.append(
        section('Format', formatList(AFORMATS.map(f => [f.id, f.label, !mimeFor(f), null, f.sub]), cfg.af, v => { cfg.af = v; save(); render(); })),
        cfg.af === 'mp3' ? section('Bitrate', chips([[96, '96k'], [128, '128k'], [192, '192k'], [256, '256k'], [320, '320k']], cfg.kbps, v => { cfg.kbps = v; save(); })) : null,
        section('Sample rate', chips([[44100, '44.1 kHz'], [48000, '48 kHz']], cfg.sr, v => { cfg.sr = v; save(); })));
    } else {
      body.append(section('Format', formatList([['srt', 'SRT', false, null, 'Works with YouTube and most players'], ['vtt', 'VTT', false, null, 'Web video captions'], ['txt', 'TXT', false, null, 'Plain transcript']], cfg.sf, v => { cfg.sf = v; save(); })));
    }
    upd();
  };
  const upd = () => {
    const d = totalDur();
    if (cfg.tab === 'video') {
      const [W, H] = exportDims(cfg.res); const mb = W * H * cfg.fps * QUALITY[cfg.q] * d / 8 / 1e6;
      info.textContent = `${W} × ${H}, about ${Math.max(1, Math.round(mb))} MB. Export runs in real time (${fmt(d)}), keep the app open.`;
    } else if (cfg.tab === 'audio') info.textContent = `Length ${fmt(d)}. Effects, EQ and volume are included.`;
    else info.textContent = `${S.p.texts.length} subtitles.`;
  };
  const run = async () => {
    const fname = (name.value.trim() || defaultName()).replace(/[\\/:*?"<>|]+/g, '_');
    if (cfg.tab === 'video') {
      const f = VFORMATS.find(x => x.id === cfg.vf), mime = mimeFor(f);
      if (!mime) return toast('This format is not supported on this device', 'err');
      const [W, H] = exportDims(cfg.res);
      const vbr = clamp(Math.round(W * H * cfg.fps * QUALITY[cfg.q]), 800000, 80000000);
      await exportVideo({ mime, ext: f.ext, W, H, fps: cfg.fps, vbr, subs: cfg.subs, name: fname, label: f.label });
    } else if (cfg.tab === 'audio') {
      await exportAudio({ f: AFORMATS.find(x => x.id === cfg.af), kbps: cfg.kbps, sr: cfg.sr, name: fname });
    } else {
      if (!S.p.texts.length) return toast('There are no subtitles to export', 'err');
      closeSheet();
      const mime = cfg.sf === 'vtt' ? 'text/vtt' : 'text/plain';
      await deliver(new Blob([subsFile(cfg.sf)], { type: mime }), fname + '.' + cfg.sf, 'doc');
    }
  };
  b.append(chips([['video', 'Video'], ['audio', 'Audio only'], ['subs', 'Subtitles']], cfg.tab, v => { cfg.tab = v; save(); render(); }, 'tabs'),
    body, section('File name', name), info, go);
  render();
}
function formatList(opts, cur, onPick) {
  const w = h('div', { class: 'fmt-list' });
  const r = c => {
    w.innerHTML = '';
    for (const [v, l, dis, , sub] of opts) w.append(h('button', { class: 'fmt' + (v === c ? ' on' : ''), disabled: dis, onclick: () => { onPick(v); r(v); } },
      h('b', null, l), h('small', null, dis ? 'Not supported on this device' : sub)));
  };
  r(cur); return w;
}


// ---------- WebM / Matroska duration patch ----------
// MediaRecorder writes "live" Matroska files with no Duration, which breaks seeking in many players.
function readVint(b, p) {
  const first = b[p]; let len = 1, mask = 0x80;
  while (len <= 8 && !(first & mask)) { len++; mask >>= 1; }
  if (len > 8) return null;
  let val = first & (mask - 1), allOnes = val === mask - 1;
  for (let i = 1; i < len; i++) { val = val * 256 + b[p + i]; if (b[p + i] !== 0xff) allOnes = false; }
  return { len, val, unknown: allOnes };
}
function readId(b, p) { const v = readVint(b, p); if (!v) return null; let id = 0; for (let i = 0; i < v.len; i++) id = id * 256 + b[p + i]; return { len: v.len, id }; }
async function fixMatroskaDuration(blob, seconds) {
  try {
    const head = new Uint8Array(await blob.slice(0, Math.min(blob.size, 1 << 20)).arrayBuffer());
    let idx = -1;
    for (let i = 0; i < head.length - 4; i++) if (head[i] === 0x15 && head[i + 1] === 0x49 && head[i + 2] === 0xA9 && head[i + 3] === 0x66) { idx = i; break; }
    if (idx < 0) return blob;
    const sz = readVint(head, idx + 4); if (!sz || sz.unknown) return blob;
    const start = idx + 4 + sz.len, end = start + sz.val; if (end > head.length) return blob;
    let p = start, scale = 1e6;
    while (p < end) {
      const id = readId(head, p); if (!id) return blob;
      const s2 = readVint(head, p + id.len); if (!s2) return blob;
      const dataAt = p + id.len + s2.len;
      if (id.id === 0x2AD7B1) { let v = 0; for (let i = 0; i < s2.val; i++) v = v * 256 + head[dataAt + i]; scale = v || 1e6; }
      if (id.id === 0x4489) return blob; // already has a duration
      p = dataAt + s2.val;
    }
    const dur = new Uint8Array(11); dur[0] = 0x44; dur[1] = 0x89; dur[2] = 0x88;
    new DataView(dur.buffer).setFloat64(3, seconds * 1e9 / scale);
    const newSize = sz.val + 11, sizeBytes = new Uint8Array(8); sizeBytes[0] = 0x01;
    let n = newSize; for (let i = 7; i >= 1; i--) { sizeBytes[i] = n & 0xff; n = Math.floor(n / 256); }
    return new Blob([head.subarray(0, idx + 4), sizeBytes, head.subarray(start, end), dur, head.subarray(end), blob.slice(head.length)], { type: blob.type });
  } catch (e) { return blob; }
}

// ---------- progress modal ----------
function showProgress(title, canvas, onCancel) {
  const m = $('#modal'); m.innerHTML = '';
  const bar = h('i'), pctEl = h('b', null, '0%'), sub = h('small', null, 'Keep the screen on and the app open');
  m.append(h('div', { class: 'modal-card' }, h('h2', null, title), canvas || null, h('div', { class: 'bar' }, bar), h('div', { class: 'prog-row' }, pctEl, sub),
    onCancel ? btn('Cancel', 'close', onCancel, 'ghost-btn') : null));
  m.classList.add('open');
  return { set(p, txt) { p = clamp(p, 0, 1); bar.style.width = (p * 100).toFixed(1) + '%'; pctEl.textContent = Math.floor(p * 100) + '%'; if (txt) sub.textContent = txt; } };
}
function hideProgress() { $('#modal').classList.remove('open'); $('#modal').innerHTML = ''; }
let wake = null;
async function wakeOn() { try { wake = await navigator.wakeLock.request('screen'); } catch (e) {} }
function wakeOff() { try { wake && wake.release(); } catch (e) {} wake = null; }

async function exportVideo(c) {
  const d = totalDur(); if (d <= 0) return toast('Add something to the timeline first', 'err');
  pause(); closeSheet(); S.sel = null; renderDock(); renderTimeline();
  const cv = h('canvas', { class: 'exp-canvas' }); cv.width = c.W; cv.height = c.H;
  const g = cv.getContext('2d');
  let E = null;
  const prog = showProgress('Exporting ' + c.label, cv, () => { if (E) E.cancel = true; });
  wakeOn();
  try {
    syncVideos(0, false); await new Promise(r => setTimeout(r, 400));
    const ctx = actx(); await ctx.resume();
    const msd = ctx.createMediaStreamDestination(); const master = AudioFX.makeMaster(ctx); master.out.connect(msd);
    drawFrame(g, c.W, c.H, 0, { subs: c.subs });
    const vs = cv.captureStream(c.fps);
    const rec = new MediaRecorder(new MediaStream([...vs.getVideoTracks(), ...msd.stream.getAudioTracks()]), { mimeType: c.mime, videoBitsPerSecond: c.vbr, audioBitsPerSecond: 192000 });
    const chunks = []; rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    const stopped = new Promise(r => { rec.onstop = r; });
    rec.start(1000);
    engineStart(0, master.in);
    E = S.exporting = { g, W: c.W, H: c.H, rec, d, subs: c.subs, prog, cancel: false, last: 0 };
    await stopped;
    engineStop(); for (const m of S.media.values()) if (m.el) m.el.pause();
    try { master.out.disconnect(); } catch (e) {}
    vs.getTracks().forEach(t => t.stop());
    S.exporting = null;
    if (E.cancel) { hideProgress(); toast('Export canceled'); return; }
    prog.set(1, 'Saving file…');
    let blob = new Blob(chunks, { type: c.mime.split(';')[0] });
    if (/webm|matroska/.test(c.mime)) blob = await fixMatroskaDuration(blob, d);
    hideProgress();
    await deliver(blob, c.name + '.' + c.ext, 'video');
  } catch (e) {
    S.exporting = null; engineStop(); hideProgress(); toast('Export failed: ' + e.message, 'err', 8000);
  } finally { wakeOff(); seek(0); }
}
function exportTick() {
  const E = S.exporting; if (!E || E.stopping) return;
  const t = Math.min(engineNow(), E.d);
  syncVideos(t, true);
  drawFrame(E.g, E.W, E.H, t, { subs: E.subs });
  const now = performance.now();
  if (now - E.last > 200) { E.last = now; E.prog.set(t / E.d, fmt(t) + ' of ' + fmt(E.d) + '. Keep the screen on and the app open'); }
  if (t >= E.d || E.cancel) { E.stopping = true; setTimeout(() => { try { E.rec.stop(); } catch (e) {} }, E.cancel ? 0 : 250); }
}

async function exportAudio(c) {
  const segs = audioSegments(); if (!segs.length) return toast('There is no audio in this project yet', 'err');
  pause(); closeSheet();
  let cancel = false;
  const prog = showProgress('Exporting ' + c.f.label, null, c.f.offline ? null : () => { cancel = true; });
  try {
    prog.set(0.05, 'Mixing audio…');
    const buf = await AudioFX.mixdown(segs, 0, totalDur(), c.sr, 2);
    let blob;
    if (c.f.id === 'mp3') blob = await AudioFX.toMp3(buf, c.kbps, p => prog.set(0.1 + p * 0.85, 'Encoding MP3…'));
    else if (c.f.id === 'wav') blob = AudioFX.toWav(buf);
    else {
      const mime = mimeFor(c.f), ctx = actx(); await ctx.resume();
      const dest = ctx.createMediaStreamDestination(), src = ctx.createBufferSource(); src.buffer = buf; src.connect(dest);
      const rec = new MediaRecorder(dest.stream, { mimeType: mime, audioBitsPerSecond: 192000 }), chunks = [];
      rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      const stopped = new Promise(r => { rec.onstop = r; });
      rec.start(500); const t0 = ctx.currentTime; src.start();
      await new Promise(r => { src.onended = r; const iv = setInterval(() => { prog.set((ctx.currentTime - t0) / buf.duration, 'Recording ' + fmt(ctx.currentTime - t0) + ' of ' + fmt(buf.duration)); if (cancel) { try { src.stop(); } catch (e) {} } }, 250); src.addEventListener('ended', () => clearInterval(iv)); });
      await new Promise(r => setTimeout(r, 250)); rec.stop(); await stopped;
      if (cancel) { hideProgress(); return toast('Export canceled'); }
      blob = new Blob(chunks, { type: mime.split(';')[0] });
      if (/webm/.test(mime)) blob = await fixMatroskaDuration(blob, buf.duration);
    }
    hideProgress();
    await deliver(blob, c.name + '.' + c.f.ext, 'audio');
  } catch (e) { hideProgress(); toast('Export failed: ' + e.message, 'err', 8000); }
}

// ---------- saving files ----------
const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
function plugin(n) { const C = window.Capacitor; return (C.Plugins && C.Plugins[n]) || (C.registerPlugin && C.registerPlugin(n)); }
function blobToB64(blob) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
}
async function writeChunked(FS, path, blob, directory, onP) {
  const CH = 3 * 1024 * 1024;
  for (let i = 0; i === 0 || i < blob.size; i += CH) {
    const data = await blobToB64(blob.slice(i, i + CH));
    if (i === 0) await FS.writeFile({ path, data, directory, recursive: true });
    else await FS.appendFile({ path, data, directory });
    onP && onP(Math.min(1, (i + CH) / blob.size));
    if (!blob.size) break;
  }
}
async function saveBlob(blob, name, kind, onP) {
  if (!isNative()) {
    const url = URL.createObjectURL(blob);
    const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return { native: false, where: 'your Downloads folder' };
  }
  const FS = plugin('Filesystem');
  try { await FS.requestPermissions(); } catch (e) {}
  const pub = kind === 'video' ? 'Movies' : kind === 'audio' ? 'Music' : 'Documents';
  const tries = [['EXTERNAL_STORAGE', pub + '/ReelForge/' + name, pub + '/ReelForge'], ['DOCUMENTS', 'ReelForge/' + name, 'Documents/ReelForge'], ['CACHE', name, 'app storage (tap Share to keep it)']];
  let lastErr;
  for (const [dir, path, label] of tries) {
    try { await writeChunked(FS, path, blob, dir, onP); const { uri } = await FS.getUri({ path, directory: dir }); return { native: true, uri, where: label }; }
    catch (e) { lastErr = e; }
  }
  throw new Error('Could not save the file: ' + (lastErr && lastErr.message));
}
let lastSaved = null;
async function deliver(blob, name, kind) {
  const prog = showProgress('Saving', null, null);
  try {
    const r = await saveBlob(blob, name, kind, p => prog.set(p, 'Writing ' + (blob.size / 1e6).toFixed(1) + ' MB…'));
    hideProgress();
    lastSaved = Object.assign({ name, size: blob.size, blob }, r);
    openSheet('saved');
  } catch (e) { hideProgress(); toast(e.message, 'err', 8000); }
}
function buildSaved(b) {
  const s = lastSaved; if (!s) return;
  b.append(h('div', { class: 'saved' },
    h('span', { class: 'saved-ic', html: icon('check', 30) }),
    h('b', null, s.name), h('small', null, (s.size / 1e6).toFixed(1) + ' MB, saved to ' + s.where)),
  h('div', { class: 'row-btns' },
    s.native ? btn('Share or save to…', 'share', async () => { try { await plugin('Share').share({ title: s.name, files: [s.uri], dialogTitle: 'Share ' + s.name }); } catch (e) { if (!/cancel/i.test(e.message || '')) toast(e.message, 'err'); } }, 'primary') : null,
    btn('Done', 'check', closeSheet)));
}

// ===================== init =====================
async function loadFonts() {
  const set = new Set(Presets.SUB_STYLES.map(s => `${s.weight} 40px "${s.font}"`));
  await Promise.all([...set].map(f => document.fonts.load(f).catch(() => {})));
  requestDraw();
}
function initNative() {
  if (!isNative()) return;
  try { const App = plugin('App'); App.addListener('backButton', () => {
    if ($('#modal').classList.contains('open')) return;
    if (sheetCtx) return closeSheet();
    if (S.sel) { S.sel = null; renderTimeline(); renderDock(); requestDraw(); return; }
    if (S.playing) return pause();
    App.minimizeApp();
  }); } catch (e) {}
  try { const SB = plugin('SystemBars'); SB && SB.setStyle && SB.setStyle({ style: 'DARK' }); } catch (e) {}
}
function newProjectAction() {
  if ((S.p.main.length || S.p.audio.length || S.p.texts.length) && !confirm('Start a new project? The current edit will be cleared.')) return;
  pause(); snapshot(); S.p = newProject(); S.sel = null; S.t = 0; layoutStage(); afterEdit();
}
function init() {
  $('#btnPlay').innerHTML = icon('play', 26);
  $('#btnUndo').innerHTML = icon('undo', 20); $('#btnRedo').innerHTML = icon('redo', 20);
  $('#btnNew').innerHTML = icon('file', 20);
  $('#zoomIn').innerHTML = icon('zoomIn', 18); $('#zoomOut').innerHTML = icon('zoomOut', 18);
  $('#tlAdd').innerHTML = icon('plus', 22);
  $('#btnPlay').onclick = () => (S.playing ? pause() : play());
  $('#btnUndo').onclick = undo; $('#btnRedo').onclick = redo; $('#btnNew').onclick = newProjectAction;
  $('#btnExport').onclick = () => { if (totalDur() <= 0) return toast('Add a video, photo or audio first'); openSheet('export'); };
  $('#zoomIn').onclick = () => setZoom(S.pps * 1.4); $('#zoomOut').onclick = () => setZoom(S.pps / 1.4);
  $('#tlAdd').onclick = () => pickMedia(); $('#btnEmptyAdd').onclick = () => pickMedia();
  $('#sheetClose').onclick = closeSheet;
  $('#inMedia').onchange = e => { importFiles(e.target.files, 'main'); e.target.value = ''; };
  $('#inAudio').onchange = e => { importFiles(e.target.files, 'audio'); e.target.value = ''; };
  $('#inAudioVid').onchange = e => { importFiles(e.target.files, 'audio'); e.target.value = ''; };
  $('#inSubs').onchange = async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    const items = parseSubs(await f.text()); if (!items.length) return toast('No subtitles found in that file', 'err');
    edit(() => { const st = STYLE_BY_ID[S.p.defStyle]; for (const x of items) S.p.texts.push({ id: uid(), start: x.start, end: x.end, text: x.text, styleId: S.p.defStyle, x: 0.5, y: defaultY(st), scale: 1, words: null, ov: {} }); });
    closeSheet(); toast(`Imported ${items.length} subtitles`);
  };
  window.addEventListener('keydown', e => {
    if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
    if (e.code === 'Space') { e.preventDefault(); S.playing ? pause() : play(); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    else if (e.key === 'Delete' || e.key === 'Backspace') deleteSelected();
    else if (e.key.toLowerCase() === 's' && !e.ctrlKey) splitSelected();
    else if (e.key === 'Escape') { if (sheetCtx) closeSheet(); else { S.sel = null; renderTimeline(); renderDock(); } }
  });
  let rz; window.addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(() => { layoutStage(); renderTimeline(); }, 120); });
  initTimeline(); initPreviewGestures(); layoutStage(); renderTimeline(); renderDock(); updateTC(); updateUndoBtns(); updateEmpty();
  initNative(); loadFonts();
  requestAnimationFrame(loop);
}
function pickMedia() { $('#inMedia').click(); }
document.addEventListener('DOMContentLoaded', init);
