// Runs after `npx cap add android`: adds app settings, permissions, icons and splash screens.
import fs from 'fs';
import path from 'path';

const main = 'android/app/src/main';
const manifestPath = path.join(main, 'AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  console.error('android/ folder not found. Run "npx cap add android" first.');
  process.exit(1);
}
let xml = fs.readFileSync(manifestPath, 'utf8');

// Bigger memory budget for video/audio decoding; legacy storage for Android 10.
if (!xml.includes('android:largeHeap')) {
  xml = xml.replace('<application', '<application\n        android:largeHeap="true"\n        android:requestLegacyExternalStorage="true"');
}
// Editor layout is designed for portrait.
if (!xml.includes('android:screenOrientation')) {
  xml = xml.replace(/<activity(\s)/, '<activity\n            android:screenOrientation="portrait"$1');
}
// Storage permissions are only needed on old Android versions (9 and below / 12 and below).
const perms = [
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />'
];
for (const p of perms) {
  const name = p.match(/name="([^"]+)"/)[1];
  if (!xml.includes(name)) xml = xml.replace('</manifest>', '    ' + p + '\n</manifest>');
}
fs.writeFileSync(manifestPath, xml);
console.log('Patched AndroidManifest.xml');

// Copy icons and splash screens over the Capacitor defaults.
function copyDir(src, dst) {
  if (!fs.existsSync(src)) return 0;
  let n = 0;
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) n += copyDir(s, d);
    else { fs.copyFileSync(s, d); n++; }
  }
  return n;
}
console.log('Copied ' + copyDir('resources/android/res', path.join(main, 'res')) + ' icon and splash files');
