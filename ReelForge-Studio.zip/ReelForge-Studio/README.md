# ReelForge Studio

Android video editor: multi-track timeline, trimming and splitting, 120 subtitle styles, 36 audio effects, 10-band equalizer, ElevenLabs AI voice with synced subtitles, auto captions, and export to MP4, WebM, MKV, MP3, WAV, M4A, Opus, SRT and VTT.

See **INSTALL_GUIDE.md** for how to build the APK (free, via GitHub Actions) and install it on your phone.
